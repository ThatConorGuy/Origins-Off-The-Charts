# Origins: Off The Charts - v2

Minecraft Java 1.21.1 / Fabric / Java 21+

Replace the previous addon with `origins-off-the-charts-1.21.1-v2.19.jar` on server and clients. Keep compatible Origins and Fabric API dependencies. Install one version of the addon.

## v2.19
- Villager-converted wolves have 60 health (30 hearts / three rows); existing packmates are corrected automatically.
- A transformed Alpha can crouch-strike a player with an empty hand to start a one-minute conversion. A wolf growl accompanies the bite.
- During conversion, players can move but suffer nausea, poison, Weakness V and Slowness IV with soul particles.
- Success (40%) replaces their origin with conversion-only **Beta Werewolf** and shows a confirmation title. Failure (60%) kills them without changing their original origin or evolution progress.
- Betas inherit two-thirds of their turner's werewolf stat bonuses and healing, mirror their unlocks/upgrades, and retain the last inherited strength while their turner is offline.
- Betas cannot evolve or buy upgrades independently, auto-tame wolves, turn others, call packs, or deal attributed combat damage to their turner. Their P menu explains inherited progression.
- Conversion timers and bonds persist in player world data and survive JAR replacement; bonds survive normal respawns.
- The awakening subtitle is now short enough to fit normal GUI sizes.

## v2.18 visuals
- WolfsBane Extract resembles black redstone dust. Existing extract stacks update automatically.
- Coated arrows have black tips and a smoke trail, synchronized in multiplayer.
- Awakened werewolves see dark silhouettes around coated item sprites and WolfsBane flowers, plus nearby flower and projectile outlines. Flower scans are cached and restricted to loaded chunks.
- Player evolution and upgrades remain in world saves when replacing the JAR.

## Original v2 implementation (see later version history for current progression)
- Ten minutes of active-play grace, then a five-second awakening during the next night. Origin benefits and drawbacks are dormant until awakening.
- Four evolution tiers: awakening, 60 EP, 180 EP, 420 EP. Ordinary positive XP and origin activity awards both contribute to the ordinary XP bar and permanent EP. Spending XP or dying does not revoke unlocks.
- Fourteen sets of three named quests. Hunters gain 12 bonus XP per mob kill, woodland origins 3 per mature crop/cocoa harvest, Rubberman 2 per jump and per measured horizontal block after attacks, and RPI Student 4 per supported ore mined.
- Quest rewards: 20/40/80 XP, supplies, golden apples, diamonds. Titles, action-bar progress, and `/ott status`.
- Progression gates all legacy powers, including direct Java helpers. Advanced custom engineering, discounts, elastic strikes and Exalted effects respect their tiers.
- Evolution upgrades movement modestly, and evolved hunting origins receive extra well-fed healing.
- Werewolf villager conversion: at tier III, crouch and attack bare-handed while transformed. One minute of soul particles, hurt audio and renderer shaking, then 60% death / 40% conversion. Conversion state saves.
- Blood wolves: owner-bound vanilla wolf behavior, 120 HP, 10 base attack damage, 0.36 movement speed, 6 armor, 2 HP healing per 2 seconds. Dark-red eyes and no collar. Full-moon frenzy targets nearby creatures except the turner; an owner strike calms them for that moon. Frenzy and conversion data synchronize and persist.
- Fresh dangerous loot chests: 30% extra loot roll on first player opening. Existing origin-compatible vanilla gear and consumables; no separate custom-item list was recoverable from earlier files.
- Historical release filenames renamed v1.N; original binary contents and timestamps retained. Future release labels v2.1, v2.2, etc.
- Updated 12-page PDF with an awakening cover, progression/pack/loot rules, current cards for all fourteen origins, and named quest paths.

## Verification
- Java 21 compilation and intermediary remapping passed.
- Minecraft 1.21.1 / Fabric 0.16.14 / Origins pre.3 loaded and validated 460 power definitions without power parse errors.
- Isolated world validation: 577 assertions passed. Covers all fourteen origin identities, dormant gates, ordinary health and scale, awakening, ordinary XP evolution, XP spending, one-time quest rewards, saved progression, frenzy owner protection/calm/reload/next-moon behavior, one-minute conversion, saved conversion, both random outcomes, and spawned packmate stats/ownership.
- Client preflight successfully transformed fifteen targeted classes, including wolf collar and living renderer hooks, without opening a window.
- Every PDF page rendered and visually inspected.
- Automated fixtures do not replace a connected multiplayer visual and balance playtest. Rubberman knockback awards measure short-window horizontal displacement after successful damage; they are not a physics-only impulse measurement.
- World/socket validation uses test-only mixins to bypass the sandbox's port restriction. Those mixins are absent from the production JAR.

## Sources and rebuilding
`java/` contains the v2 Java additions. `resources/` contains all production data, textures, metadata, and the preserved compiled legacy baseline from v1.21. The legacy mod's complete original source was not present in the newest JAR; older partial sources are retained separately.

Use the included `build.py` with Java 21, ECJ, Tiny Remapper, the 1.21.1 named/intermediary game jars, named Apoli, Yarn build 3 mappings, and the normal Fabric/CCA/Calio/game dependency classpath. It recompiles the v2 additions and remaps injection targets/shadow fields. The preserved legacy baseline is already patched; do not apply PatchLegacy repeatedly.

Validation fixtures are source-only companion tools. Do not add the validation fixture JAR to a real server.

## v2.1 shared start
Operators can run `/ott pause` before inviting everyone, then `/ott unpause` when ready. This freezes the day/night cycle in every dimension and holds dormant players’ grace periods and awakening rituals. Joining, movement, mobs and normal gameplay remain active. The pause persists through server restarts using the daylight-cycle gamerule; vanilla changes to that gamerule also control awakening countdowns.

## v2.2 Evolution and Skills
Press P (rebindable in Controls) or run `/ott menu`. Hover over icons for status, quests, unlocks, instructions and upgrade costs. Locked skills expose their name and required tier only. Click an unlocked upgrade book with the left mouse button to buy a rank. Each of the 14 origins has three upgrade paths. Skill Level 2 costs 30 raw XP points and requires Evolution II or the later skill unlock; Skill Level 3 costs 60 XP points and requires Mastery. XP purchases do not reduce lifetime EP or evolution tier.
Routine action-bar progress is removed. Major titles now hold for 8 seconds. Every origin has tier II and III automatic unlocks. Grasshopper, Vampire and Wight also gain a small automatic health reserve; Berserker and Minotaur unlock firmer footing.

## Updating a running world
Stop the server, back up the existing world, remove the previous addon JAR, install v2.11 on server and all clients, and restart with the same world and player UUIDs. Keep `world/playerdata`; do not reset it. v2/v2.1 `OffTheChartsV2` records migrate in place to schema 3 without changing EP, evolution, quests, activities, grace or ritual. Purchased ranks live in the same record and copy through respawn. Future compatible builds must retain this save key and existing origin/skill IDs. v1 had no evolution records to migrate. Restore both a world backup and its matching JAR if rolling back. Switching origins still starts a new progression for the newly selected origin.

## Rebuilding
The build script accepts `--fabric-api` pointing to the original Minecraft 1.21.1 Fabric API JAR; it remaps the key-binding and client lifecycle APIs for compilation. Supply the other toolchain arguments listed by `python3 build.py --help`. Compiled legacy baseline classes in resources are retained; new v2/ui classes are rebuilt from Java.

## v2.3 balance
Hell Hound: while transformed, being in water or rain disables offensive flames and all healing and causes one health point of damage every two seconds. Hound and Berserker forms double activity exhaustion. Berserker form cannot equip chest armor or elytra and attacks 20% slower; leaving it applies Weakness I for 10 seconds and Slowness I for 5 seconds. Yeti attacks 15% slower and swims 30% slower after awakening; its existing cold depletion penalties remain. Every new drawback begins after awakening. Existing progress and skill IDs remain unchanged.

## v2.4 compact selector and ongoing quests
P now opens a custom Origins-frame selector, not a chest inventory. Upgrades show the selected skill, short bonus, price, XP and rank. Use arrows to browse and Upgrade to purchase. Skills is a separate tab for unlocked instructions; Quests shows the current objective pair and reward. Escape/Done closes the menu. All purchases remain server-validated.
Ongoing quests begin at awakening and never end. Objectives use fresh counters for each assignment. Universal travel, jumping, breaking blocks, logs, swimming, sprinting and XP combine with origin-specific hunting, harvesting, ore mining or launching enemies. Normal assignments avoid the last eight activity combinations; targets and rewards vary within easy bounds. Completion grants 14-24 XP and assigns another quest automatically without HUD spam. A free swap (20-second persistent cooldown) picks basic movement/block objectives and gives no XP. The original three one-time milestones remain as additional rewards.
Active quests, progress, history, serial numbers and swap cooldown live in the same outside-the-JAR player save record as evolution and upgrades. Existing v2.3 ranks and evolution are retained; the first ongoing quest is assigned automatically.

## v2.6: ten themed evolutions
Awakening is Evolution 1. Levels 2-10 require lifetime EXP thresholds of 300, 1000, 2400, 4500, 7500, 11500, 17000, 24000 and 33000 plus a fresh origin-specific trial. Evolution tab under P shows both gates. Existing tiers/ranks/EXP are retained; new trial baselines are initialized on the first active tick. EXP is positive earned vanilla XP since awakening; purchases spend current vanilla XP points and never subtract lifetime EXP.
Quests now use origin-specific hunting, crops, ore, movement, stealth and flight objectives, with eligible pools and recent-template avoidance. Rewards scale with weighted difficulty and target size. Completion sends a title and chat; the next task arrives after 30-150 active seconds and announces in chat. Free swaps give accessible origin practice, no reward, once per 20 seconds. Visible hostile mobs within 24 blocks can trigger a marked-target threat quest. Defeating that exact entity earns at least 80 EXP, scaled by max health. Missing/dead targets are canceled after 20 seconds and another task scheduled.
Purchased skill levels 2/3/4/5 cost 30/60/150/300 points, at evolution 2/4/7/10 respectively (or the skill unlock if later). Last two purchased ranks add half steps; the cap is 50 percent above the old purchased bonus. Automatic speed/healing bonuses remain capped. Creative/spectator activity is excluded from quest/evolution counters.

## v2.8
224 named quests (16 per origin) add pack growth, specific prey, fire, farming, building, research and movement. Goals increase with evolution; rewards scale with the next EXP threshold and difficulty. Free swaps award smaller practice rewards. Twenty charged or limited-use relics appear through a separate 18% dangerous-chest roll; the Blackened Heart is rarer. See the guide for controls.
Werewolf auto-taming checks loaded wolves within 80 blocks every five seconds. Full transformation is 2.45 blocks tall, and transformed wolves step over one-block ledges without breaking sprint. Wolfsbane nausea ends with poison. Owned wolves regroup after respawn, including sitting wolves; unloaded wolves return when their chunks load. Existing evolution, purchases and quests remain in world player data when replacing the JAR.
Server-world validation and client transformation checks passed. Connected multiplayer playtesting remains necessary. Earlier sections document historical releases; current progression has ten levels and the P-key journal.

## v2.9
Both transformed werewolf states ignore leaf collisions and step over one-block ledges without a manual jump. Human form keeps normal collision and step behavior. Forest passage uses the Minecraft leaves tag, supporting tagged modded leaves. Existing player progress is retained.

## v2.10
Evolution EXP thresholds reduced 30 percent: levels 2-10 require 210, 700, 1680, 3150, 5250, 8050, 11900, 16800 and 23100 lifetime EXP. Origin trials and skill prices stay the same. Quest payouts retain their previous values; existing saved EXP, evolution and purchases are retained.

## v2.11
Skill levels 2-5 now require evolutions 1, 2, 3 and 4 respectively, or the original skill unlock if later. Prices remain 30, 60, 150 and 300 EXP points. Retains v2.10 reduced evolution thresholds and all saved purchases.

## v2.12
Operator command `/ott awaken [players]` starts the five-second awakening regardless of daylight, grace period or pause. No argument targets yourself; player names and selectors work from the server console. Already-awakened players keep their progress and are skipped.

Operator debugging: `/ott evolve [players]` grants one evolution level (maximum 10) without spending EXP or requiring a trial. `/ott unlockshop [players]` persistently removes upgrade purchase locks after awakening, while prices and rank caps remain. Purchased bonuses still respect their underlying ability unlock. All three commands support player names/selectors; no target means yourself.

## v2.13
Operator command `/ott maxupgrades <players>` grants evolution 10, unlocks the shop and sets every upgrade path for the current origin to skill level 5. Supports `@s`, `@a`, names and other player selectors. Existing EXP is preserved; progress saves through restarts and JAR replacements.

## v2.14
- Rubberman gains 12 extra blocks of safe fall distance after awakening (15 total), retaining half fall damage beyond that. Saved progress is unchanged.

## v2.15
- Pink tulips become black-petaled, green-stemmed Wolfsbane, including existing plants. Only Wolfsbane triggers the werewolf flower curse, after five continuous seconds carrying it or touching its planted/potted block. Leaving resets exposure; antidote blocks exposure effects.
- Shapeless coating: one Wolfsbane plus one sword or axe. Preserves wear, enchantments and custom name; black blades for all twelve vanilla swords/axes. Adds six melee damage before other modifiers/defenses against awakened Werewolf players or blood-bound turned wolves. Coatings are permanent and cannot stack.
- Rodent Repellent: three uses; twenty-second cloud of radius six, slowing and weakening squirrels and preventing concealment/gliding. Bug Trap: three uses; one-minute radius-two area slowing and weakening grasshoppers and blocking spring legs/gliding. Penalties linger five seconds after leaving. Natural unopened chest loot has a 12 percent roll for one of these; dangerous relic rolls also include them. Other origins are unaffected. Clouds and remaining duration persist in world saves.
- Grasshopper, Sneaky Squirrel, Rubberman and RPI Student need half the hunter EXP thresholds and half their previous trial targets. Quest payouts, saved EXP, ranks and previous evolutions stay intact; the P menu uses the new origin-specific thresholds.

## v2.16
- Awakened werewolves can eat bones for eight hunger points (four bars) and bone blocks for twenty points (the full row), in any form. Uses normal eating, consumes one item and caps at twenty hunger. No bonus saturation. Other origins and dormant players keep normal item behavior.

## v2.17
- WolfsBane Flower (formerly pink tulip) causes exposure within a spherical three-block radius of planted/potted flowers, retaining five-second grace and inventory exposure.
- Flower crafting yields one tagged WolfsBane Extract instead of pink dye. Combine one extract with one arrow, sword or axe. One arrow per craft, with the existing six-damage bonus on arrow hits against werewolves or turned wolves. Other pink dye recipes remain ordinary dye. Existing coated weapons retain their coating.
