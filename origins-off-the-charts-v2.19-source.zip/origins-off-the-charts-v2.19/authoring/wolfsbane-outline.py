from pathlib import Path
import sys,json
sys.path.insert(0,'/tmp');from tiny_png import Image
r=Path('v2/resources');models=r/'assets/minecraft/models/item';textures=r/'assets/beasts_origins/textures/item'
for p in list(models.glob('*_sword.json'))+list(models.glob('*_axe.json'))+[models/'arrow.json',models/'pink_dye.json',models/'pink_tulip.json']:
 if p.name=='pink_tulip.json':
  d={'parent':'minecraft:item/generated','textures':{'layer0':'minecraft:block/pink_tulip'},'overrides':[]};source=r/'assets/minecraft/textures/block/pink_tulip.png';name='wolfsbane_flower';cmd=1153
 else:
  d=json.loads(p.read_text());match=next((o for o in d.get('overrides',[]) if o['predicate'].get('custom_model_data') in (151,152)),None)
  if not match:continue
  name=match['model'].split('/')[-1];source=textures/(name+'.png');cmd=match['predicate']['custom_model_data']+1000
 im=Image.open(source);out=Image.new('RGBA',(im.width,im.height),(0,0,0,0))
 for y in range(im.height):
  for x in range(im.width):
   color=im.getpixel((x,y))
   if color[3]:out.putpixel((x,y),color)
   elif any(0<=x+dx<im.width and 0<=y+dy<im.height and im.getpixel((x+dx,y+dy))[3] for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]):out.putpixel((x,y),(24,8,13,255))
 name+='_outlined';out.save(textures/(name+'.png'))
 (r/'assets/beasts_origins/models/item'/f'{name}.json').write_text(json.dumps({'parent':'minecraft:item/generated','textures':{'layer0':f'beasts_origins:item/{name}'}}))
 d['overrides'].append({'predicate':{'custom_model_data':cmd},'model':f'beasts_origins:item/{name}'});p.write_text(json.dumps(d,indent=2))
