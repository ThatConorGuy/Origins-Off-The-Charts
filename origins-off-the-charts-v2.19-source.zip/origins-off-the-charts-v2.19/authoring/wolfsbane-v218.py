from pathlib import Path
import sys,json,zipfile,io
sys.path.insert(0,'/tmp');from tiny_png import Image
root=Path('v2/resources');g='/Users/conorchampagne/Documents/Codex/2026-10-02/if-i-give-you-this-minecraft/work/wolf-renderer/minecraft-named.jar'
with zipfile.ZipFile(g) as z:
 for source,target,kind in [('item/redstone.png','item/wolfsbane_extract.png','dust'),('item/arrow.png','item/wolfsbane_arrow.png','item'),('entity/projectiles/arrow.png','entity/wolfsbane_arrow.png','entity')]:
  im=Image.open(io.BytesIO(z.read('assets/minecraft/textures/'+source))).convert('RGBA')
  print(source,im.width,im.height)
  for y in range(im.height):
   for x in range(im.width):
    r,gg,b,a=im.getpixel((x,y));tip=kind=='dust' or kind=='item' and x>=8 and y<=7 or kind=='entity' and x<4
    if a and tip:
     shade=int(max(r,gg,b)*.15);im.putpixel((x,y),(max(8,shade),max(6,shade-3),max(9,shade),a))
  p=root/'assets/beasts_origins/textures'/target;p.parent.mkdir(parents=True,exist_ok=True);im.save(p)
for item,cmd,name in [('pink_dye',152,'wolfsbane_extract'),('arrow',151,'wolfsbane_arrow')]:
 p=root/'assets/minecraft/models/item'/f'{item}.json';p.write_text(json.dumps({'parent':'minecraft:item/generated','textures':{'layer0':f'minecraft:item/{item}'},'overrides':[{'predicate':{'custom_model_data':cmd},'model':f'beasts_origins:item/{name}'}]},indent=2))
 p=root/'assets/beasts_origins/models/item'/f'{name}.json';p.write_text(json.dumps({'parent':'minecraft:item/generated','textures':{'layer0':f'beasts_origins:item/{name}'}},indent=2))
