from pathlib import Path
from zipfile import ZipFile
from tiny_png import Image
from io import BytesIO
import json
r=Path('v2/resources');game='/Users/conorchampagne/Documents/Codex/2026-10-02/if-i-give-you-this-minecraft/work/wolf-renderer/minecraft-intermediary.jar'
with ZipFile(game) as z:
 im=Image.open(BytesIO(z.read('assets/minecraft/textures/block/pink_tulip.png'))).convert('RGBA')
 for y in range(im.height):
  for x in range(im.width):
   a,b,c,alpha=im.getpixel((x,y))
   if alpha and not b>a and not b>c:
    shade=12+int((a+b+c)/3*.10);im.putpixel((x,y),(shade,shade,shade+3,alpha))
 p=r/'assets/minecraft/textures/block/pink_tulip.png';p.parent.mkdir(parents=True,exist_ok=True);im.save(p)
 for material in ['wooden','stone','iron','golden','diamond','netherite']:
  for tool in ['sword','axe']:
   name=f'{material}_{tool}';im=Image.open(BytesIO(z.read(f'assets/minecraft/textures/item/{name}.png'))).convert('RGBA');mask=Image.open(BytesIO(z.read(f'assets/minecraft/textures/item/diamond_{tool}.png'))).convert('RGBA')
   for y in range(im.height):
    for x in range(im.width):
     a,b,c,alpha=mask.getpixel((x,y));old=im.getpixel((x,y))
     blade=alpha and b>a+8 and c>a+8 and (tool=='axe' or x-y>=3)
     if blade and old[3]:
      shade=12+int((a+b+c)/3*.12);im.putpixel((x,y),(shade,shade,shade+3,old[3]))
   p=r/f'assets/beasts_origins/textures/item/wolfsbane_{name}.png';p.parent.mkdir(parents=True,exist_ok=True);im.save(p)
   p=r/f'assets/beasts_origins/models/item/wolfsbane_{name}.json';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps({'parent':'minecraft:item/handheld','textures':{'layer0':f'beasts_origins:item/wolfsbane_{name}'}},indent=2)+'\n')
   model=json.loads(z.read(f'assets/minecraft/models/item/{name}.json'));model.setdefault('overrides',[]).append({'predicate':{'custom_model_data':151},'model':f'beasts_origins:item/wolfsbane_{name}'});p=r/f'assets/minecraft/models/item/{name}.json';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(model,indent=2)+'\n')
p=r/'assets/minecraft/lang/en_us.json';p.parent.mkdir(parents=True,exist_ok=True);d=json.loads(p.read_text()) if p.exists() else {};d.update({'block.minecraft.pink_tulip':'Wolfsbane','item.minecraft.pink_tulip':'Wolfsbane','block.minecraft.potted_pink_tulip':'Potted Wolfsbane'});p.write_text(json.dumps(d,indent=2)+'\n')
# Enlarged contact sheet for checking blade and flower silhouettes.
canvas=Image.new('RGBA',(16*5,16*3),(100,110,110,255));images=[r/'assets/minecraft/textures/block/pink_tulip.png']+sorted((r/'assets/beasts_origins/textures/item').glob('wolfsbane_*.png'))
for i,p in enumerate(images):canvas.alpha_composite(Image.open(p).convert('RGBA'),((i%5)*16,(i//5)*16))
Path('tmp/wolfsbane-assets').mkdir(parents=True,exist_ok=True);canvas.resize((800,480),Image.Resampling.NEAREST).save('tmp/wolfsbane-assets/contact.png')
