import struct,zlib,math
class Image:
 class Resampling:NEAREST=0
 def __init__(self,w,h,pixels):self.width=w;self.height=h;self.pixels=pixels
 @staticmethod
 def new(mode,size,color):return Image(*size,[color]*math.prod(size))
 @staticmethod
 def open(source):
  b=source.read() if hasattr(source,'read') else open(source,'rb').read();pos=8;raw=b'';pal=[];alpha=[]
  while pos<len(b):
   size=struct.unpack('>I',b[pos:pos+4])[0];kind=b[pos+4:pos+8];v=b[pos+8:pos+8+size];pos+=size+12
   if kind==b'IHDR':w,h,depth,ctype,_,_,interlace=struct.unpack('>IIBBBBB',v);assert not interlace
   elif kind==b'PLTE':pal=[tuple(v[i:i+3]) for i in range(0,len(v),3)]
   elif kind==b'tRNS':alpha=list(v)
   elif kind==b'IDAT':raw+=v
  raw=zlib.decompress(raw);channels={6:4,2:3,3:1}[ctype];stride=(w*channels*depth+7)//8;bpp=max(1,(channels*depth+7)//8);offset=0;prev=[0]*stride;pixels=[]
  for y in range(h):
   f=raw[offset];offset+=1;row=list(raw[offset:offset+stride]);offset+=stride
   for i in range(stride):
    a=row[i-bpp] if i>=bpp else 0;bb=prev[i];c=prev[i-bpp] if i>=bpp else 0
    if f==1:v=a
    elif f==2:v=bb
    elif f==3:v=(a+bb)//2
    elif f==4:
     p=a+bb-c;aa=abs(p-a);ab=abs(p-bb);ac=abs(p-c);v=a if aa<=ab and aa<=ac else bb if ab<=ac else c
    else:v=0
    row[i]=(row[i]+v)&255
   for x in range(w):
    if ctype==3:
     bit=x*depth;idx=(row[bit//8]>>(8-depth-bit%8))&((1<<depth)-1);pixels.append(pal[idx]+(alpha[idx] if idx<len(alpha) else 255,))
    else:
     p=tuple(row[x*channels:(x+1)*channels]);pixels.append(p if ctype==6 else p+(255,))
   prev=row
  return Image(w,h,pixels)
 def convert(self,m):return self
 def getpixel(self,xy):x,y=xy;return self.pixels[y*self.width+x]
 def putpixel(self,xy,value):x,y=xy;self.pixels[y*self.width+x]=value
 def save(self,path):
  def chunk(k,v):return struct.pack('>I',len(v))+k+v+struct.pack('>I',zlib.crc32(k+v))
  rows=b''.join(b'\0'+bytes(c for pixel in self.pixels[y*self.width:(y+1)*self.width] for c in pixel) for y in range(self.height))
  b=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',self.width,self.height,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(rows))+chunk(b'IEND',b'');open(path,'wb').write(b)
 def alpha_composite(self,im,xy):
  ox,oy=xy
  for y in range(im.height):
   for x in range(im.width):
    p=im.getpixel((x,y))
    if p[3]:self.putpixel((x+ox,y+oy),p)
 def resize(self,size,resample):
  w,h=size;return Image(w,h,[self.getpixel((x*self.width//w,y*self.height//h)) for y in range(h) for x in range(w)])
