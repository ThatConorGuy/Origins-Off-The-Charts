from pathlib import Path
import json,textwrap,re
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'resources';OUT=ROOT/'Origins-Off-The-Charts-v2-Guide.pdf'
GOLD=(.95,.76,.36);WHITE=(.91,.92,.95);MUTED=(.65,.68,.73);GREEN=(.53,.8,.4);RED=(.96,.4,.42)
class PDF:
 def __init__(self):self.pages=[];self.ops=[]
 def rect(self,x,y,w,h,color):self.ops.append('%.3f %.3f %.3f rg %.2f %.2f %.2f %.2f re f'%(*color,x,y,w,h))
 def text(self,t,x,y,size=11,bold=False,color=WHITE):
  t=t.replace('\u2019',"'").replace('\u2014',' - ').replace('\u2013','-').encode('ascii','replace').decode().replace('\\','\\\\').replace('(','\\(').replace(')','\\)')
  self.ops.append('BT /%s %s Tf %.3f %.3f %.3f rg 1 0 0 1 %.2f %.2f Tm (%s) Tj ET'%('B' if bold else 'F',size,*color,x,y,t))
 def para(self,t,x,y,w=510,size=11,leading=15,color=WHITE,bold=False):
  lines=textwrap.wrap(t,max(15,int(w/(size*.49))))
  for l in lines:self.text(l,x,y,size,bold,color);y-=leading
  return y-6
 def base(self,title):
  if self.ops:self.pages.append('\n'.join(self.ops).encode());self.ops=[]
  self.rect(0,0,612,792,(.055,.065,.09));self.rect(0,748,612,44,(.025,.03,.045));self.text('ORIGINS: OFF THE CHARTS',36,767,12,True,GOLD);self.text('v2.19  |  MC 1.21.1',455,767,9,color=MUTED)
  self.text(title,36,716,24,True);self.rect(36,42,540,1,(.23,.25,.3));self.text('Explore the rest in game.',36,25,8,color=MUTED);self.text(str(len(self.pages)+1),563,25,8,color=MUTED)
 def section(self,title,y,body):self.text(title,42,y,13,True,GOLD);return self.para(body,42,y-23,520)-14
 def save(self):
  self.pages.append('\n'.join(self.ops).encode());objs=[b'',b'',b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>'];kids=[]
  for stream in self.pages:
   sid=len(objs)+1;objs.append(b'<< /Length '+str(len(stream)).encode()+b' >>\nstream\n'+stream+b'\nendstream');pid=len(objs)+1;objs.append(('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F 3 0 R /B 4 0 R >> >> /Contents %d 0 R >>'%sid).encode());kids.append(pid)
  objs[0]=b'<< /Type /Catalog /Pages 2 0 R >>';objs[1]=('<< /Type /Pages /Count %d /Kids [%s] >>'%(len(kids),' '.join('%d 0 R'%n for n in kids))).encode();out=bytearray(b'%PDF-1.4\n%\xe2\xe3\xcf\xd3\n');offs=[0]
  for i,obj in enumerate(objs,1):offs.append(len(out));out.extend(('%d 0 obj\n'%i).encode()+obj+b'\nendobj\n')
  start=len(out);out.extend(('xref\n0 %d\n0000000000 65535 f \n'%(len(objs)+1)).encode());out.extend(''.join('%010d 00000 n \n'%n for n in offs[1:]).encode());out.extend(('trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n'%(len(objs)+1,start)).encode());OUT.write_bytes(out)
p=PDF();p.base('THE AWAKENING')
p.text('SURVIVE.',42,627,49,True,WHITE);p.text('AWAKEN.',42,566,49,True,GOLD);p.text('EVOLVE.',42,505,49,True,RED)
p.rect(42,365,528,104,(.11,.13,.17));p.para('Begin as an ordinary survivor. After ten minutes of active play, your next night brings a five-second awakening: particles, a new instinct, and every weakness of your chosen origin.',58,445,494,13,19)
y=321;y=p.section('POWER FOLLOWS YOUR NATURE',y,'Hunt, harvest, leap or mine. Normal Minecraft XP and your origin activities earn EXP. Complete themed trials to evolve, then choose which unlocked skills to improve. Press P for your status, quests and instructions.')
y=p.section('A SYSTEM THAT REMEMBERS',y,'Fourteen starting origins, ten evolution levels, and permanent skill upgrades. Your world saves your progress outside the JAR. A werewolf bite can also create a loyal Beta Werewolf whose strength follows its turner.')
p.text('QUICK START / 2     ORIGINS / 4-10     RELICS / 13',42,89,10,True,GOLD)
p.base('Quick start / EXP, quests and P')
def concise(title,y,body):
 p.text(title,42,y,12,True,GOLD);return p.para(body,42,y-20,520,10.5,14)-9
y=665;y=concise('AWAKEN',y,'Complete 10 minutes of active-play grace, then wait for night. The five-second ritual activates most powers and all drawbacks. Offline time does not count. The awakening subtitle now fits beneath the origin name.')
y=concise('EARN EXP, EVEN WITHOUT A QUEST',y,'All positive normal Minecraft XP earned after awakening also adds lifetime evolution EXP: mobs, XP-bearing ores, smelting, breeding, trading and XP bottles. These extra origin bonuses use the normal XP bar too:')
p.text('ORIGIN',42,y,10,True,GOLD);p.text('EXTRA EXP',230,y,10,True,GOLD);y-=22
for name,bonus in [('Hunting origins','12 per creature killed; excludes players and tamed pets.'),('Grasshopper / Sneaky Squirrel','3 per mature crop or cocoa block broken.'),('Rubberband Man','2 per jump; 2 per knockback block, up to 16 per hit.'),('RPI Student','4 per supported ore block mined.')]:
 p.text(name,42,y,9,True);p.para(bonus,230,y,340,9,12);p.rect(42,y-14,528,.5,(.16,.18,.22));y-=25
p.para('Hunting origins = the other ten starting origins. Beta Werewolves have inherited progression instead; see the Werewolf abilities on page 8.',42,y,522,9,12,color=MUTED);y-=40
y=concise('TWO BALANCES',y,'Spendable EXP is your current Minecraft XP points: use it for skill upgrades, enchanting or repairs. Lifetime EXP never falls when you spend XP or die. Evolution 2-10 needs both lifetime EXP and a fresh themed trial; see page 12.')
y=concise('PRESS P',y,'Upgrades: browse one skill at a time; see its effect, cost, current EXP and level. Skills: descriptions and controls appear only after unlocking. Quests: objectives, progress, reward and free swap (20-second cooldown). Evolution: your next EXP threshold and trial. /ott menu opens the same window; rebind P in Controls.')
y=concise('QUESTS THAT FIT YOUR ORIGIN',y,'Each starting origin has 16 quest templates, unlocked gradually. Recent tasks are avoided; difficulty and rewards grow with evolution. Completion has an eight-second title. The next task is announced after 30-150 seconds of active play. Visible nearby threats can create specific-target quests. Routine progress stays under P; original supply milestones pay once.')
assert y>55, ('quick start overflow',y)
p.base('Skills / Choose what to develop')
p.para('Unlocked skills work automatically. Each starting origin has three stat upgrade paths. Skill levels 2-5 cost 30 / 60 / 150 / 300 EXP points and need Evolution 1 / 2 / 3 / 4 respectively, or the ability unlock if later. The last two purchased ranks add half steps. Spending EXP never removes your evolution.',42,665,522,11,15,color=MUTED)
p.text('ORIGIN',42,567,10,True,GOLD);p.text('THREE UPGRADE CHOICES',182,567,10,True,GOLD)
catalog=json.loads((R/'ott-skills.json').read_text());y=538
order=['dragon','grasshopper','minotaur','yeti','rubberman','rpi_student','vampire','wight','wendigo','werewolf','berserker','chimera','sneaky_squirrel','hell_hound']
for key in order:
 origin=json.loads((R/'data/beasts_origins/origins'/f'{key}.json').read_text());p.text(origin.get('name',key.replace('_',' ').title()),42,y,10,True);p.para(' / '.join(a['name'] for a in catalog[key] if a['effect']),182,y,386,9,12);p.rect(42,y-21,528,.5,(.16,.18,.22));y-=30
p.para('Beta Werewolves have no independent upgrades or evolutions. Their P menu shows inherited skills, and they gain strength as their turner evolves or upgrades. Alpha powers are excluded.',42,85,522,10,14,color=MUTED)
HINTS=json.loads((ROOT/'authoring/guide-hints.json').read_text())
lang={}
for f in (R/'assets').glob('*/lang/en_us.json'):lang.update(json.loads(f.read_text()))
def txt(s):return lang.get(s,s)
origins=[]
for f in (R/'data/beasts_origins/origins').glob('*.json'):
 j=json.loads(f.read_text());key=f.stem;rows=[]
 if key=='beta_werewolf':continue
 for power in j['powers']:
  path=power.split(':',1)[1]
  if '/guide_' not in path:continue
  a=json.loads((R/'data/beasts_origins/powers'/f'{path}.json').read_text());color=GREEN if '/guide_g' in path else RED if '/guide_r' in path else GOLD;rows.append((txt(a.get('name','')),HINTS[key][a.get('name','').split(' [')[0]],color))
 origins.append((key,txt(j.get('name',key.replace('_',' ').title())),txt(j.get('description','')),rows))
order=['dragon','grasshopper','minotaur','yeti','rubberman','rpi_student','vampire','wight','wendigo','werewolf','berserker','chimera','sneaky_squirrel','hell_hound'];origins.sort(key=lambda a:order.index(a[0]))
for offset in range(0,len(origins),2):
 p.base('Choose your nature');p.text('GREEN / BENEFIT     RED / DRAWBACK     GOLD / MIXED',38,690,8,True,MUTED)
 for ix,(key,name,flavor,rows) in enumerate(origins[offset:offset+2]):
  wolf_page=any(o[0]=='werewolf' for o in origins[offset:offset+2]);height=(200 if ix==0 else 390) if wolf_page else 282;top=(668 if ix==0 else 450) if wolf_page else 668-ix*303;p.rect(36,top-height,540,height,(.105,.12,.155));p.text(name.upper(),48,top-25,18,True,GOLD);y=p.para(flavor,48,top-46,514,9.5,12,color=MUTED)
  for name,desc,col in rows:
   if not name or key=='werewolf':continue
   if key=='rubberman' and name=='Soft Landing':desc='After awakening, falls up to 15 blocks are safe; larger falls remain cushioned.'
   text=name+': '+desc
   y=p.para(text,48,y,513,8.8,10.3,color=col)+3
  if key=='werewolf':
   pack=[
    ('Forms / Physique','Call forth the beast, or conceal it behind a human face. Claws, strength and a changed voice follow.',GREEN),
    ('Woodland Instinct','The forest yields to your changed forms. Even the bones of your prey can nourish you.',GREEN),
    ('Predator\'s Senses','Darkness reveals prey; a dangerous black bloom is harder to overlook.',GREEN),
    ('The Hunt','Answer the moon\'s hunger and earn its favor. Ignore it at your peril.',GOLD),
    ('Unarmored / Silver','The curse refuses armor. Iron carries a silver-like sting.',RED),
    ('WolfsBane','A black-petaled flower poisons those who linger near it. Pots offer no refuge.',RED),
    ('Black Coatings','The flower\'s extract can darken a weapon. Its bite is especially cruel to wolf-kind.',RED),
    ('Alpha / Pack Call','Wild wolves recognize a leader. Call your pack close, or command it to wait.',GREEN),
    ('The Bite','A transformed, crouching, empty-handed strike may pass on the curse. Some hosts survive; others do not.',GOLD),
    ('Blood-bound Packmate','A villager may become a stronger, loyal wolf with crimson eyes and no collar.',GREEN),
    ('Full-moon Frenzy','The moon can break a packmate\'s obedience. A blow from its turner can restore recognition.',RED),
    ('Beta Werewolf','A surviving player takes on a new nature. Its strength follows its turner, and loyalty binds its claws.',GOLD),
    ('Beta Limits','A Beta cannot lead, pass on the curse, develop powers independently or strike its turner.',RED)
   ]
   for title,body,col in pack:y=p.para(title+': '+body,48,y,513,10,13,color=col)+4
  if y<top-height+14:raise RuntimeError('Origin panel overflow '+key+' '+str(y))
  activity='Ripe harvests' if key in ['grasshopper','sneaky_squirrel'] else 'Leaps and launching foes' if key=='rubberman' else 'Mining useful ores' if key=='rpi_student' else 'Hunting living mobs'
  p.text('ORIGIN ACTIVITIES / '+activity,48,top-height+12,8,True,MUTED)
p.base('Server / Shared starts and safe updates')
y=665;y=p.section('START TOGETHER',y,'Before everyone joins, an operator uses /ott pause; when ready, use /ott unpause. Daylight and awakening countdowns wait while players can move. Pause survives restarts. Each dormant player then finishes their remaining grace period.')
y=p.section('KEEP YOUR WORLD AND PLAYER DATA',y,'Stop the server cleanly and back up the world. Remove the old addon JAR, install origins-off-the-charts-1.21.1-v2.19.jar on the server and every client, then restart. Use one addon version at a time. Keep Minecraft 1.21.1, Java 21+, Fabric API and compatible Origins dependencies.')
y=p.section('PROGRESS LIVES OUTSIDE THE JAR',y,'World/playerdata/<player UUID>.dat saves evolution, lifetime EXP, upgrades, quests, awakening, conversion timers and Beta bonds. Keep the same world and account UUIDs. Existing v2 progress migrates automatically. Existing villager-converted wolves are corrected to 60 maximum health; no reset is needed.')
y=p.section('CHECK, BACK UP, ROLL BACK',y,'Open P after updating to check your progress. Beta Werewolves see inherited progression. Ordinary origin changes start a new progression; failed player conversions keep the previous one. For rollback, restore the world backup with its matching addon version. Never delete playerdata to update.')
y=p.section('OPERATOR COMMANDS',y,'/ott awaken <players>: five-second ritual, bypassing grace/night/pause. /ott evolve <players>: one evolution level. /ott unlockshop <players>: remove purchase locks, keeping EXP costs. /ott maxupgrades <players>: Evolution 10 and all skill upgrades. Targets accept @s, @a or names; these commands do not independently upgrade Betas.')
y=p.section('FINDING HIDDEN ITEMS',y,'Unopened dangerous chests have a separate 18% relic roll: ancient cities, bastions, fortresses, End cities, mansions, strongholds and dungeons. The Blackened Heart is rarer. Natural chests also have a 12% chance of rodent repellent or a bug trap. Opened chests never reroll; see page 13 for relic controls.')
assert y>55, ('server overflow',y)
p.base('Evolution / EXP and themed trials')
p.para('Awakening is Level 1. Every new evolution needs lifetime EXP AND a fresh trial. EXP carries forward; trial counts restart at each level. Existing saved evolutions stay unlocked. Open P > Evolution for your exact current requirement.',42,665,522,10.5,14,color=MUTED)
p.text('LEVEL',42,600,10,True,GOLD);p.text('HUNTER EXP',155,600,10,True,GOLD);p.text('NON-HUNTER EXP',345,600,10,True,GOLD);y=579
for level,exp in enumerate([0,210,700,1680,3150,5250,8050,11900,16800,23100],1):
 p.text(str(level),42,y,9,True);p.text(str(exp),155,y,9);p.text(str(exp//2),345,y,9);p.rect(42,y-8,528,.5,(.16,.18,.22));y-=20
p.text('EARLY TRIALS / LEVELS 2, 3, 4',42,365,11,True,GOLD)
y=p.para('Hunters: 10 creatures; 30 hostiles; then a player OR 3 enemies with at least 40 maximum health. Grasshopper: 16 ripe crops; 50 jumps; 200 glide blocks. Squirrel: 20 crops; 40 logs; 300 sneak blocks. Rubberband Man: 60 jumps; 60 launched blocks; 1,000 sprint blocks. Student: 20 ores; 50 logs; 6 diamond ores.',42,346,522,10,13)-6
p.text('LATER TRIALS / LEVELS 5-10',42,y,11,True,GOLD);y-=19
y=p.para('Hunters alternate themed kills with hostile kills: Werewolf/Vampire/Wight/Wendigo hunt at night; Yeti in cold biomes; Hell Hound/Dragon in the Nether; Berserker in beast form; Kanima poisoned foes; Minotaur bare-handed. Counts rise by (level - 3) x 15. The final hunter trial is 175 enemies with at least 40 maximum health.',42,y,522,10,13)
y=p.para('Non-hunter trials alternate: Grasshopper crops/gliding; Squirrel harvest/logs/gliding; Rubberband Man jumps/launches; Student ores/diamonds. Counts use (level - 3) x 32 crops or 300 glide blocks; x 48 harvest/logs or 350 glide blocks; x 90 jumps/launches; x 50 ores or 8 diamond ores respectively. Their EXP and trial counts are easier; quest payouts stay unchanged.',42,y,522,10,13)
y=p.para('Threat quests mark a visible hostile within 24 blocks. Only your kill of that target completes it; reward scales with evolution and enemy health. If it disappears, the task cancels and another is scheduled. Free swaps give no reward. Beta Werewolves have no independent evolution trials or upgrade purchases.',42,y,522,9.5,12,color=MUTED)
assert y>50, ('trials overflow',y)
p.base('Hidden relics / A short field reference')
p.para('Use = right-click. Hold = main hand or offhand. Carry = anywhere in inventory. Relics answer their intended origin; charged Dragonfire Bottles, repellent and traps can be used by anyone. Empty charges cannot activate effects. Repellent/traps also appear in natural chests. Their penalties end 5s after leaving the area.',42,665,522,10,14,color=MUTED)
p.text('RELIC / ORIGIN',42,601,10,True,GOLD);p.text('USE AND LIMIT',235,601,10,True,GOLD);p.rect(42,589,528,1,(.27,.29,.34))
items=[
('Wolfsbane Antidote / Werewolf','Use once: clears poisoning; suppresses wolfsbane for 90s.'),
('Moonstone Amulet / Werewolf','Use: 120s of moon control. Three charges; hunt duties remain.'),
('Silver Restraint Charm / Werewolf','Hold: softens silver damage, poison and recovery lock. 120 hits.'),
('Blood Flask / Vampire','Carry to bank blood from kills (40 max); use to drink stored blood.'),
('Daylight Ring / Vampire','Hold: sunlight protection. Depletes after 120 exposed seconds.'),
('Bloodstone / Vampire','Carry: slowly banks surplus blood (20 max); releases at low reserve.'),
('Kanima Venom Vial / Kanima','Sneak-use extracts a dose; use throws paralysis poison. 5-min recovery.'),
('Kanima Suppressant / Kanima','Use once: 120s of reduced form drain and faster stamina recovery.'),
('Wight Soul Vessel / Wight','Sneak-use banks absorption (24 max); use restores up to eight points.'),
('Blackened Heart / Wight','Hold: one death rescue. Leaves severe weakness and hunger. Very rare.'),
('Cooling Talisman / Wendigo','Carry: suppresses heat penalties. Degrades over 180 hot seconds.'),
('Frozen Heart / Wendigo','Use once: 180s of strength, speed and reduced hunger drain.'),
('Dragonfire Bottle / Dragon','Dragon sneak-use charges breath (2-min recovery); use releases fireball.'),
('Rainward Charm / Dragon','Hold: halves origin water damage. Depletes over 180 wet seconds.'),
('Weighted Boots / Grasshopper','Use: 60s of grounded jumping. Six charges.'),
('Frog Repellent / Grasshopper','Use: 120s of frog relief and repulsion. Three charges.'),
('Elastic Wrap / Rubberband Man','Hold: reduces received knockback by 60%. 180 impacts.'),
('Compression Ball / Rubberband Man','Hold: stores received knockback; releases it into the next melee hit.'),
('Cramming Notes / RPI Student','Use: removes commute slowdown for 120s, then severe hunger for 60s. Three uses.'),
('Student ID / RPI Student','Carry: additional villager discount. 100 shop sessions.'),
('Rodent Repellent / Anyone','Use: 20s, radius 6. Slows/weakens squirrels; blocks stealth/gliding. 3 uses.'),
('Bug Trap / Anyone','Use: 60s, radius 2. Slows/weakens grasshoppers; blocks springs/gliding. 3 uses.')]
y=570
for name,body in items:
 p.para(name,42,y,180,8.5,10,bold=True);p.para(body,235,y,335,8.5,10);p.rect(42,y-18,528,.5,(.16,.18,.22));y-=23
p.save();print('Created',OUT,'pages:',len(p.pages))
