package conor.beasts.v2;
public interface WolfState {boolean ott$turned();boolean ott$frenzy();void ott$turned(boolean b);void ott$calm();}
