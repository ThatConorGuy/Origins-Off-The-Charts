package conor.beasts.v2;
import net.minecraft.entity.Entity;import net.minecraft.entity.player.PlayerEntity;import net.minecraft.server.network.ServerPlayerEntity;
public final class BalanceRules {
 public static boolean doused(Entity e){return e instanceof PlayerEntity p&&Progression.origin(p).equals("hell_hound")&&Progression.resource(p,"progression/tier")>=1&&Progression.resource(p,"hell_hound/form")==1&&p.isWet();}
 public static void tick(ServerPlayerEntity p){if(doused(p)&&p.age%40==0)p.damage(p.getWorld().getDamageSources().drown(),1);}
}
