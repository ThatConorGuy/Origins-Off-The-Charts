package conor.beasts.v2;
import net.minecraft.nbt.NbtCompound;
public interface ProgressData { NbtCompound ott$data(); void ott$data(NbtCompound n); }
