package conor.beasts.v2;
public interface TrapState {String ott$trap();void ott$trap(String id);}
