package conor.beasts.v2.client;
import conor.beasts.v2.*;import net.minecraft.client.render.entity.feature.WolfCollarFeatureRenderer;import net.minecraft.client.util.math.MatrixStack;import net.minecraft.client.render.VertexConsumerProvider;import net.minecraft.entity.passive.WolfEntity;import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(WolfCollarFeatureRenderer.class)public abstract class CollarMixin {
 @Inject(method="render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/entity/passive/WolfEntity;FFFFFF)V",at=@At("HEAD"),cancellable=true)private void collar(MatrixStack m,VertexConsumerProvider v,int l,WolfEntity w,float a,float b,float c,float d,float e,float f,CallbackInfo ci){if(((WolfState)w).ott$turned())ci.cancel();}
}
