package conor.beasts.v2.client;
import conor.beasts.v2.Wolfsbane;import net.minecraft.entity.projectile.*;import net.minecraft.particle.ParticleTypes;import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(PersistentProjectileEntity.class)public abstract class WolfsbaneTrailMixin {
 @Shadow protected boolean inGround;
 @Inject(method="tick",at=@At("TAIL"))private void trail(CallbackInfo ci){var e=(PersistentProjectileEntity)(Object)this;if(e.getWorld().isClient&&!inGround&&e instanceof ArrowEntity a&&((conor.beasts.v2.CoatedArrow)a).ott$coated()&&e.getVelocity().lengthSquared()>.01){var v=e.getVelocity();for(int i=0;i<2;i++)e.getWorld().addParticle(ParticleTypes.SMOKE,e.getX()-v.x*i*.3,e.getY()-v.y*i*.3,e.getZ()-v.z*i*.3,0,.005,0);}}
}
