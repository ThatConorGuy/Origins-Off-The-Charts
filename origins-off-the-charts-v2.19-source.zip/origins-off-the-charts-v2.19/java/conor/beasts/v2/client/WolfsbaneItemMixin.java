package conor.beasts.v2.client;
import conor.beasts.v2.*;import net.minecraft.client.MinecraftClient;import net.minecraft.client.render.item.ItemRenderer;import net.minecraft.item.*;import net.minecraft.component.DataComponentTypes;import net.minecraft.component.type.CustomModelDataComponent;import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;
@Mixin(ItemRenderer.class)public abstract class WolfsbaneItemMixin {
 @ModifyVariable(method="getModel",at=@At("HEAD"),argsOnly=true)private ItemStack outline(ItemStack stack){var p=MinecraftClient.getInstance().player;if(p==null||!Progression.origin(p).equals("werewolf")||Progression.resource(p,"progression/tier")<1||!WolfsbaneSight.visible(stack))return stack;var copy=stack.copy();copy.set(DataComponentTypes.CUSTOM_MODEL_DATA,new CustomModelDataComponent(stack.isOf(Items.PINK_TULIP)?1153:Wolfsbane.extract(stack)?1152:1151));return copy;}
}
