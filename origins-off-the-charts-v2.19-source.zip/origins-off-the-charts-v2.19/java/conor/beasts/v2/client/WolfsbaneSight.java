package conor.beasts.v2.client;
import conor.beasts.v2.*;


import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.block.Blocks;
import net.minecraft.entity.*;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.item.*;
import net.minecraft.util.math.*;
import java.util.*;
public final class WolfsbaneSight  {
 private final List<BlockPos> flowers=new ArrayList<>();private long nextScan;private Object lastWorld;
 public static boolean visible(ItemStack s){return s.isOf(Items.PINK_TULIP)||Wolfsbane.coated(s)||Wolfsbane.extract(s);}
 public void render(net.minecraft.client.render.Camera camera,org.joml.Matrix4f view){
  var mc=MinecraftClient.getInstance();var p=mc.player;var w=mc.world;
  if(w==null||p==null||!Progression.origin(p).equals("werewolf")||Progression.resource(p,"progression/tier")<1)return;
  if(lastWorld!=w||w.getTime()>=nextScan){flowers.clear();lastWorld=w;nextScan=w.getTime()+10;var base=p.getBlockPos();for(var b:BlockPos.iterate(base.add(-12,-6,-12),base.add(12,6,12))){if(!w.isChunkLoaded(b))continue;var s=w.getBlockState(b);if(s.isOf(Blocks.PINK_TULIP)||s.isOf(Blocks.POTTED_PINK_TULIP))flowers.add(b.toImmutable());}}
  var matrices=new net.minecraft.client.util.math.MatrixStack();matrices.multiplyPositionMatrix(view);var cam=camera.getPos();matrices.push();matrices.translate(-cam.x,-cam.y,-cam.z);var lines=mc.getBufferBuilders().getEntityVertexConsumers().getBuffer(RenderLayer.getLines());
  for(var b:flowers){var s=w.getBlockState(b);if(!s.isOf(Blocks.PINK_TULIP)&&!s.isOf(Blocks.POTTED_PINK_TULIP))continue;for(var box:s.getOutlineShape(w,b).getBoundingBoxes())WorldRenderer.drawBox(matrices,lines,box.offset(b).expand(.025),.13f,.055f,.075f,1f);}
  for(var e:w.getEntities()){if(e==p||e.squaredDistanceTo(p)>24*24)continue;boolean show=e instanceof ItemEntity i&&visible(i.getStack())||e instanceof ArrowEntity a&&((conor.beasts.v2.CoatedArrow)a).ott$coated();if(show)WorldRenderer.drawBox(matrices,lines,e.getBoundingBox().expand(.04),.13f,.055f,.075f,1f);}
  matrices.pop();mc.getBufferBuilders().getEntityVertexConsumers().draw(RenderLayer.getLines());
 }
}
