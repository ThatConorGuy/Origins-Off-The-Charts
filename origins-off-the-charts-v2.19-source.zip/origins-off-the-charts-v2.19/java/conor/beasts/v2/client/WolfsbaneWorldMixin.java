package conor.beasts.v2.client;
import net.minecraft.client.render.*;import org.joml.Matrix4f;import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(WorldRenderer.class)public abstract class WolfsbaneWorldMixin {
 @Unique private final WolfsbaneSight ott$sight=new WolfsbaneSight();
 @Inject(method="render",at=@At("TAIL"))private void sight(RenderTickCounter ticks,boolean outline,Camera camera,GameRenderer game,LightmapTextureManager light,Matrix4f view,Matrix4f projection,CallbackInfo ci){ott$sight.render(camera,view);}
}
