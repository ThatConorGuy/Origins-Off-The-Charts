package conor.beasts.v2.client;
import conor.beasts.v2.Wolfsbane;import net.minecraft.client.render.entity.ArrowEntityRenderer;import net.minecraft.entity.projectile.ArrowEntity;import net.minecraft.util.Identifier;import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(ArrowEntityRenderer.class)public abstract class WolfsbaneArrowMixin {
 @Inject(method="getTexture(Lnet/minecraft/entity/projectile/ArrowEntity;)Lnet/minecraft/util/Identifier;",at=@At("HEAD"),cancellable=true)private void texture(ArrowEntity arrow,CallbackInfoReturnable<Identifier> ci){if(((conor.beasts.v2.CoatedArrow)arrow).ott$coated())ci.setReturnValue(Identifier.of("beasts_origins","textures/entity/wolfsbane_arrow.png"));}
}
