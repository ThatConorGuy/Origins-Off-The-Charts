package conor.beasts.v2.client;
import conor.beasts.v2.*;import net.minecraft.client.render.entity.LivingEntityRenderer;import net.minecraft.entity.LivingEntity;import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(LivingEntityRenderer.class)public abstract class TurnShakeMixin {
 @Inject(method="isShaking",at=@At("HEAD"),cancellable=true)private void shake(LivingEntity e,CallbackInfoReturnable<Boolean> ci){if(e instanceof TurnState t&&t.ott$turnTicks()>0)ci.setReturnValue(true);}
}
