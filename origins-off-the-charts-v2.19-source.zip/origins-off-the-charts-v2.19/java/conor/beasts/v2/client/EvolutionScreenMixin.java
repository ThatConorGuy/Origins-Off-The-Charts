package conor.beasts.v2.client;
import conor.beasts.ui.EvolutionScreen;import net.minecraft.client.MinecraftClient;import net.minecraft.client.gui.screen.Screen;import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;
@Mixin(MinecraftClient.class)public abstract class EvolutionScreenMixin {
 @ModifyVariable(method="setScreen",at=@At("HEAD"),argsOnly=true)private Screen journal(Screen screen){if(screen instanceof GenericContainerScreen chest&&screen.getTitle().getString().startsWith("Evolution / "))return new EvolutionScreen(chest.getScreenHandler(),screen.getTitle());return screen;}
}
