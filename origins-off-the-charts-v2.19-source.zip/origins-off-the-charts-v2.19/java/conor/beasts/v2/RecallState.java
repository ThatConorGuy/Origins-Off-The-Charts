package conor.beasts.v2;
public interface RecallState {void ott$rememberRecall(long epoch);}
