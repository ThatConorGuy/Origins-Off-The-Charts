package conor.beasts.v2;
import java.util.*;
import net.minecraft.entity.*;import net.minecraft.entity.player.*;import net.minecraft.server.network.ServerPlayerEntity;import net.minecraft.server.world.ServerWorld;import net.minecraft.nbt.NbtCompound;import net.minecraft.text.Text;import net.minecraft.particle.ParticleTypes;import net.minecraft.network.packet.s2c.play.*;import net.minecraft.item.*;import net.minecraft.entity.attribute.*;import net.minecraft.util.Identifier;
import io.github.apace100.apoli.component.PowerHolderComponent;import io.github.apace100.apoli.util.PowerUtil;
public final class Progression {
 public static final Map<String,Integer> UNLOCKS=new HashMap<>();
 public static final Set<String> PREDATORS=Set.of("werewolf","vampire","yeti","wendigo","wight","dragon","chimera","berserker","hell_hound","minotaur");
 static {
  UNLOCKS.put("werewolf/partial_transformation",2);
  UNLOCKS.put("werewolf/partial_physique",2);
  UNLOCKS.put("werewolf/killer_vision",2);
  UNLOCKS.put("werewolf/alpha_werewolf",3);
  UNLOCKS.put("werewolf/pack_call",3);
  UNLOCKS.put("vampire/bat_transformation_active",2);
  UNLOCKS.put("vampire/bat_transformation",2);
  UNLOCKS.put("vampire/bat_vision_and_strength",2);
  UNLOCKS.put("grasshopper/wings",2);
  UNLOCKS.put("sneaky_squirrel/flight",2);
  UNLOCKS.put("sneaky_squirrel/exalted",3);
  UNLOCKS.put("hell_hound/heat_wave",2);
  UNLOCKS.put("hell_hound/death_sense",3);
  UNLOCKS.put("yeti/frost_roar",2);
  UNLOCKS.put("yeti/thick_fur",3);
  UNLOCKS.put("minotaur/horn_rush",2);
  UNLOCKS.put("minotaur/steady",3);
  UNLOCKS.put("dragon/wings",2);
  UNLOCKS.put("dragon/wing_launch",2);
  UNLOCKS.put("dragon/fire_breath",3);
  UNLOCKS.put("wight/natural_thorns",3);
  UNLOCKS.put("wendigo/predatory_vision",2);
  UNLOCKS.put("wendigo/shadows_stalker",3);
  UNLOCKS.put("chimera/tail_lash",2);
  UNLOCKS.put("chimera/venomous_claws",3);
  UNLOCKS.put("rubberman/elastic_strikes",2);
  UNLOCKS.put("rubberman/elasticity",3);
  UNLOCKS.put("rpi_student/engineering_efficiency",2);
  UNLOCKS.put("rpi_student/student_discount",3);
  UNLOCKS.put("berserker/recovery",3);
  UNLOCKS.put("berserker/unyielding",2);
 }
 public static boolean skill(Entity e,String id){if(!allowed(e,id))return false;var c=PowerHolderComponent.getNullable(e);if(c!=null)for(var p:c.getPowerTypes())if(p.getPower().getId().toString().equals("beasts_origins:"+id))return true;return false;}
 public static boolean engineering(Entity e){return skill(e,"rpi_student/engineering_efficiency");}
 public static boolean discount(Entity e){return skill(e,"rpi_student/student_discount");}
 public static boolean elastic(Entity e){return skill(e,"rubberman/elastic_strikes");}
 public static String questName(String o,int q){String[] names=switch(o){case "werewolf"->new String[]{"First Blood","Pack Hunter","Alpha's Path"};case "vampire"->new String[]{"First Thirst","Blood Debt","Crimson Crown"};case "yeti"->new String[]{"Mountain Hunger","Frozen Hunter","Winter's Apex"};case "grasshopper"->new String[]{"First Harvest","Green Feast","Meadow Master"};case "sneaky_squirrel"->new String[]{"Winter Stores","Woodland Hoard","Golden Appetite"};case "rubberman"->new String[]{"Finding Your Spring","Rebound","Limitless Motion"};case "rpi_student"->new String[]{"Lab Materials","Field Research","Dean's List"};case "hell_hound"->new String[]{"Ash and Bone","Infernal Hunt","Keeper of Embers"};case "berserker"->new String[]{"Bone and Blood","Unbroken Fury","Warborn"};case "dragon"->new String[]{"First Prey","Dragon's Dominion","Sky Tyrant"};case "wight"->new String[]{"Borrowed Life","Grave Hunger","Deathless"};case "wendigo"->new String[]{"The Empty Stomach","Endless Hunt","Hunger Incarnate"};case "chimera"->new String[]{"Unstable Instinct","Many Faces","Perfect Monster"};case "minotaur"->new String[]{"First Challenge","Horn and Hoof","Labyrinth Lord"};default->new String[]{"First Instinct","Prove Your Nature","Master Your Blood"};};return names[Math.min(q,2)];}
 public static NbtCompound data(PlayerEntity p){return ((ProgressData)p).ott$data();}
 public static String origin(Entity e){var c=PowerHolderComponent.getNullable(e);if(c!=null)for(var p:c.getPowerTypes()){String s=p.getPower().getId().toString();if(s.startsWith("beasts_origins:")&&s.contains("/")&&!s.startsWith("beasts_origins:progression/"))return s.substring(15).split("/")[0];}return "";}
 public static int resource(Entity e,String id){var c=PowerHolderComponent.getNullable(e);if(c!=null)for(var p:c.getPowerTypes())if(p.getPower().getId().toString().equals("beasts_origins:"+id))return PowerUtil.getResourceValue(p);return 0;}
 public static void sync(PlayerEntity e,int tier){var c=PowerHolderComponent.getNullable(e);if(c!=null)for(var p:c.getPowerTypes())if(p.getPower().getId().toString().equals("beasts_origins:progression/tier")){if(PowerUtil.setResourceValue(p,tier))c.sync();return;}}
 public static boolean allowed(Entity e,String id){if(e instanceof PlayerEntity p&&PlayerTurning.bound(p)&&PlayerTurning.alphaPower(id))return false;if(e instanceof PlayerEntity p&&(Relics.suppress(p,id)||SurvivalItems.suppress(p,id)))return false;if(BalanceRules.doused(e)&&Set.of("hell_hound/burning_claws","hell_hound/hellfire_aura","hell_hound/heat_wave","hell_hound/regeneration").contains(id.split("_ott_")[0]))return false;if(!(e instanceof PlayerEntity))return true;return resource(e,"progression/tier")>=UNLOCKS.getOrDefault(id.split("_ott_")[0],1);}
 public static void title(ServerPlayerEntity p,String main,String sub){p.networkHandler.sendPacket(new TitleFadeS2CPacket(10,160,30));p.networkHandler.sendPacket(new SubtitleS2CPacket(Text.literal(sub)));p.networkHandler.sendPacket(new TitleS2CPacket(Text.literal(main)));}
 public static void event(PlayerEntity p,String event,int xp,int count){if(!(p instanceof ServerPlayerEntity)||resource(p,"progression/tier")==0)return;var n=data(p);n.putInt(event,n.getInt(event)+count);QuestLog.event(p,event,count);p.addExperience(xp);}
 public static void xp(PlayerEntity p,int amount){QuestLog.event(p,"xp",amount);if(amount>0&&resource(p,"progression/tier")>0){var n=data(p);n.putInt("ep",(int)Math.min(Integer.MAX_VALUE,(long)n.getInt("ep")+amount));}}
 public static void kill(LivingEntity victim,Entity attacker){if(!(attacker instanceof ServerPlayerEntity p)||victim==p||p.isCreative()||p.isSpectator()||resource(p,"progression/tier")==0||(victim instanceof net.minecraft.entity.passive.TameableEntity t&&t.isTamed()))return;
 QuestActions.kill(p,victim);if(!(victim instanceof PlayerEntity))Relics.kill(p);QuestLog.threatKilled(p,victim);if(victim instanceof PlayerEntity target){QuestLog.event(p,"player",1);if(PREDATORS.contains(origin(p))){var n=data(p);String key="rival_paid_"+target.getUuid();if(!n.contains(key)||n.getLong("age")-n.getLong(key)>=12000){n.putLong(key,n.getLong("age"));p.addExperience(QuestLog.reward(n.getInt("tier"),1.5));}}return;}if(!PREDATORS.contains(origin(p)))return;event(p,"hunt",12,1);if(victim instanceof net.minecraft.entity.mob.HostileEntity)QuestLog.event(p,"hostile",1);if(victim.getMaxHealth()>=40)QuestLog.event(p,"elite",1);long time=p.getWorld().getTimeOfDay()%24000;if(time>=13000&&time<23000)QuestLog.event(p,"night_hunt",1);if(p.getWorld().getBiome(p.getBlockPos()).value().getTemperature()<.15f)QuestLog.event(p,"cold_hunt",1);if(p.getWorld().getRegistryKey().equals(net.minecraft.world.World.NETHER))QuestLog.event(p,"nether_hunt",1);if(resource(p,origin(p)+"/form")>0||resource(p,"werewolf/form_state")>0)QuestLog.event(p,"form_hunt",1);if(victim.hasStatusEffect(net.minecraft.entity.effect.StatusEffects.POISON))QuestLog.event(p,"poison_hunt",1);if(p.getMainHandStack().isEmpty())QuestLog.event(p,"melee_hunt",1);}
 public static void tick(ServerPlayerEntity p){if(PlayerTurning.tick(p))return;SkillSystem.migrate(p);PackRecall.tick(p);BalanceRules.tick(p);String o=origin(p);if(o.isEmpty())return;var n=data(p);if(!o.equals(n.getString("origin"))){var pending=n.copy();n=new NbtCompound();if(pending.getInt("blood_turn_ticks")>0){n.putInt("blood_turn_ticks",pending.getInt("blood_turn_ticks"));n.putUuid("blood_pending_turner",pending.getUuid("blood_pending_turner"));n.put("blood_pending_snapshot",pending.getCompound("blood_pending_snapshot").copy());}n.putString("origin",o);n.putLong("age",0);((ProgressData)p).ott$data(n);sync(p,0);bonus(p,0);SkillSystem.apply(p);p.sendMessage(Text.literal("[System] A quiet day. Stay alive. Something stirs after sunset."),false);}
  if(n.getInt("tier")==0&&!n.getBoolean("force_awakening")&&!p.getServer().getOverworld().getGameRules().getBoolean(net.minecraft.world.GameRules.DO_DAYLIGHT_CYCLE)){return;}
  long age=n.getLong("age")+1;n.putLong("age",age);int tier=n.getInt("tier");long time=p.getServerWorld().getTimeOfDay()%24000;
  // A complete daylight-length grace period, then the first night. Cannot be bypassed by joining at night.
  if(tier==0){if(n.getBoolean("force_awakening")||(age>=12000&&time>=13000&&time<23000)){int ritual=n.getInt("ritual")+1;n.putInt("ritual",ritual);if(ritual==1)title(p,"THE AWAKENING","Your old life ends here.");if(ritual%5==0)p.getServerWorld().spawnParticles(ParticleTypes.SOUL,p.getX(),p.getY()+1,p.getZ(),12,.45,.8,.45,.025);if(ritual>=100){n.remove("force_awakening");n.putInt("tier",1);sync(p,1);title(p,o.replace('_',' ').toUpperCase(),"Your instincts awaken.");p.sendMessage(Text.literal("[System] Your first quest awaits. Press P for upgrades and quests."),false);}}return;}
  Wolfsbane.tick(p);
  QuestActions.scanPack(p);
  Relics.tick(p);
  QuestLog.tick(p);
  EvolutionPath.tick(p);
  if(p.age%20==0){sync(p,n.getInt("tier"));bonus(p,n.getInt("tier"));SkillSystem.apply(p);if(p.currentScreenHandler instanceof EvolutionMenu menu)menu.refresh();quests(p,o,n);}

 }
 public static String activity(String o){return o.equals("rubberman")?"motion":o.equals("rpi_student")?"study":PREDATORS.contains(o)?"hunt":"harvest";}
 public static int target(String o,int q){int[] a=activity(o).equals("hunt")?new int[]{5,15,30}:activity(o).equals("harvest")?new int[]{16,48,96}:new int[]{12,40,100};return a[Math.min(q,2)];}
 public static String quest(String o,int q){if(q>=3)return "All quests complete. Your story continues.";String a=activity(o);String verb=a.equals("hunt")?"Hunt living creatures":a.equals("harvest")?"Harvest ripe food":a.equals("study")?"Mine useful resources":"Jump or launch foes";return questName(o,q)+": "+verb+" ("+target(o,q)+" total)";}
 public static void quests(ServerPlayerEntity p,String o,NbtCompound n){int q=n.getInt("quest");if(q>=3)return;if(n.getInt(activity(o))>=target(o,q)){n.putInt("quest",q+1);p.addExperience(new int[]{20,40,80}[q]);Item reward=q==0?Items.COOKED_BEEF:q==1?Items.GOLDEN_APPLE:Items.DIAMOND;if(q==0){if(!PREDATORS.contains(o)||o.equals("minotaur"))reward=Items.BREAD;if(o.equals("grasshopper"))reward=Items.CARROT;if(o.equals("wight"))reward=Items.ROTTEN_FLESH;}var stack=new ItemStack(reward,q==0?8:q==1?2:3);if(!p.getInventory().insertStack(stack))p.dropItem(stack,false);title(p,"MILESTONE COMPLETE",questName(o,q));p.sendMessage(Text.literal("[System] Milestone rewards claimed. Press P for your current quest."),false);}}
 public static void bonus(ServerPlayerEntity p,int tier){var id=Identifier.of("beasts_origins","evolution_speed");var a=p.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);if(a==null)return;a.removeModifier(id);if(tier>=2)a.addTemporaryModifier(new EntityAttributeModifier(id,.05*Math.min(3,tier-1),EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));if(tier>=3&&PREDATORS.contains(origin(p))&&p.age%80==0&&p.getHungerManager().getFoodLevel()>=10)p.heal(.5f*Math.min(2,tier-2));}
}
