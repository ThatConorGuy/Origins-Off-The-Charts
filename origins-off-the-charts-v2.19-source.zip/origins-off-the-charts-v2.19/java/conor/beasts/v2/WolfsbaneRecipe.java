package conor.beasts.v2;
import net.minecraft.recipe.*;import net.minecraft.recipe.book.CraftingRecipeCategory;import net.minecraft.recipe.input.CraftingRecipeInput;import net.minecraft.item.*;import net.minecraft.world.World;import net.minecraft.registry.RegistryWrapper;
public final class WolfsbaneRecipe extends SpecialCraftingRecipe {
 public WolfsbaneRecipe(CraftingRecipeCategory category){super(category);}
 @Override public boolean matches(CraftingRecipeInput input,World world){int flowers=0,weapons=0;for(var s:input.getStacks()){if(s.isEmpty())continue;if(Wolfsbane.extract(s))flowers++;else if(Wolfsbane.weapon(s)&&!Wolfsbane.coated(s))weapons++;else return false;}return flowers==1&&weapons==1;}
 @Override public ItemStack craft(CraftingRecipeInput input,RegistryWrapper.WrapperLookup lookup){if(!matches(input,null))return ItemStack.EMPTY;for(var s:input.getStacks())if(Wolfsbane.weapon(s))return Wolfsbane.coat(s);return ItemStack.EMPTY;}
 @Override public boolean fits(int width,int height){return width*height>=2;}
 @Override public RecipeSerializer<?> getSerializer(){return SurvivalItems.COATING;}
}
