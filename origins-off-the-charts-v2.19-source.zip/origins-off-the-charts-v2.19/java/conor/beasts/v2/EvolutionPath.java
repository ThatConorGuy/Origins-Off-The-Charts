package conor.beasts.v2;
import java.util.*;import net.minecraft.nbt.NbtCompound;import net.minecraft.server.network.ServerPlayerEntity;
public final class EvolutionPath {
 public record Gate(String event,int count,String alternative,int alternateCount){}
 public static final int[] EXP={0,0,210,700,1680,3150,5250,8050,11900,16800,23100};
 public static final Set<String> NON_HUNTERS=Set.of("grasshopper","sneaky_squirrel","rubberman","rpi_student");
 public static int requiredExp(String origin,int level){return NON_HUNTERS.contains(origin)?EXP[level]/2:EXP[level];}
 public static Gate gate(String o,int level){var g=baseGate(o,level);return NON_HUNTERS.contains(o)?new Gate(g.event(),Math.max(1,(g.count()+1)/2),g.alternative(),g.alternateCount()):g;}
 private static Gate baseGate(String o,int level){int scale=Math.max(1,level-3);return switch(o){
 case "grasshopper"->switch(level){case 2->new Gate("harvest",32,"",0);case 3->new Gate("jump",100,"",0);case 4->new Gate("glide",400,"",0);default->new Gate(level%2==0?"glide":"harvest",level%2==0?scale*600:scale*64,"",0);};
 case "sneaky_squirrel"->switch(level){case 2->new Gate("harvest",40,"",0);case 3->new Gate("wood",80,"",0);case 4->new Gate("sneak",600,"",0);default->new Gate(level%3==0?"glide":level%3==1?"wood":"harvest",scale*(level%3==0?700:96),"",0);};
 case "rubberman"->switch(level){case 2->new Gate("jump",120,"",0);case 3->new Gate("launch",120,"",0);case 4->new Gate("sprint",2000,"",0);default->new Gate(level%2==0?"launch":"jump",scale*180,"",0);};
 case "rpi_student"->switch(level){case 2->new Gate("study",40,"",0);case 3->new Gate("wood",100,"",0);case 4->new Gate("diamond",12,"",0);default->new Gate(level%2==0?"diamond":"study",scale*(level%2==0?16:100),"",0);};
 default->switch(level){case 2->new Gate("hunt",10,"",0);case 3->new Gate("hostile",30,"",0);case 4->new Gate("player",1,"elite",3);default->new Gate(themed(o,level),scale*(level==10?25:15),"",0);};};}
 public static String themed(String o,int level){if(level==10)return "elite";return switch(o){case "vampire","wendigo","wight"->level%2==0?"night_hunt":"hostile";case "yeti"->level%2==0?"cold_hunt":"hostile";case "hell_hound","dragon"->level%2==0?"nether_hunt":"hostile";case "werewolf"->level%2==0?"night_hunt":"hostile";case "berserker"->level%2==0?"form_hunt":"hostile";case "chimera"->level%2==0?"poison_hunt":"hostile";case "minotaur"->level%2==0?"melee_hunt":"hostile";default->"hostile";};}
 public static int count(NbtCompound n,Gate g,boolean alt){String e=alt?g.alternative():g.event();return (int)Math.min(Integer.MAX_VALUE,Math.max(0,n.getLong("qs_"+e)-n.getLong("evo_start_"+e)));}
 public static void baseline(NbtCompound n){for(String key:new ArrayList<>(n.getKeys()))if(key.startsWith("qs_"))n.putLong("evo_start_"+key.substring(3),n.getLong(key));}
 public static void tick(ServerPlayerEntity p){if(PlayerTurning.bound(p))return;var n=Progression.data(p);if(!n.getBoolean("evo_v26")){n.putBoolean("evo_v26",true);baseline(n);}int next=n.getInt("tier")+1;if(next>10)return;var g=gate(Progression.origin(p),next);boolean done=count(n,g,false)>=g.count()||(!g.alternative().isEmpty()&&count(n,g,true)>=g.alternateCount());if(n.getInt("ep")>=requiredExp(Progression.origin(p),next)&&done){n.putInt("tier",next);baseline(n);Progression.sync(p,next);Progression.title(p,"EVOLUTION "+next,"Your nature deepens. Press P.");}}
 public static String requirement(String o,NbtCompound n){int next=n.getInt("tier")+1;if(next>10)return "Evolution 10 reached";var g=gate(o,next);return QuestLog.label(g.event())+" "+count(n,g,false)+"/"+g.count()+(!g.alternative().isEmpty()?" OR "+QuestLog.label(g.alternative())+" "+count(n,g,true)+"/"+g.alternateCount():"");}
}
