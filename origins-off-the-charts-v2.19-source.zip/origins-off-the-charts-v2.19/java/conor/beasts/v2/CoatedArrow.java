package conor.beasts.v2;public interface CoatedArrow {boolean ott$coated();}
