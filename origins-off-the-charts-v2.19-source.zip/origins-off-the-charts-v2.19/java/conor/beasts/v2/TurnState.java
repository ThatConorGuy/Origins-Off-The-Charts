package conor.beasts.v2;
import java.util.UUID;
public interface TurnState {int ott$turnTicks();void ott$start(UUID owner);}
