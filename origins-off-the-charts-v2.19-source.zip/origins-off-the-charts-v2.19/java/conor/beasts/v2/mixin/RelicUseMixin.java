package conor.beasts.v2.mixin;
import conor.beasts.v2.*;import net.minecraft.server.network.*;import net.minecraft.world.World;import net.minecraft.item.ItemStack;import net.minecraft.util.*;import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(ServerPlayerInteractionManager.class) public abstract class RelicUseMixin {
 @Inject(method="interactItem",at=@At("HEAD"),cancellable=true)private void use(ServerPlayerEntity p,World world,ItemStack stack,Hand hand,CallbackInfoReturnable<ActionResult> ci){if(Relics.use(p,stack))ci.setReturnValue(ActionResult.SUCCESS);}
 @Inject(method="interactBlock",at=@At("HEAD"),cancellable=true)private void place(ServerPlayerEntity p,World world,ItemStack stack,Hand hand,net.minecraft.util.hit.BlockHitResult hit,CallbackInfoReturnable<ActionResult> ci){var pos=net.minecraft.util.math.Vec3d.ofBottomCenter(hit.getBlockPos().offset(hit.getSide()));if(SurvivalItems.use(p,stack,pos))ci.setReturnValue(ActionResult.SUCCESS);}
}
