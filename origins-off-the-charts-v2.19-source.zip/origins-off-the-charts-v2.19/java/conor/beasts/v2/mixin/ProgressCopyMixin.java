package conor.beasts.v2.mixin;
import conor.beasts.v2.*;import net.minecraft.server.network.ServerPlayerEntity;import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(ServerPlayerEntity.class) public abstract class ProgressCopyMixin {
 @Inject(method="copyFrom",at=@At("TAIL"))private void copy(ServerPlayerEntity old,boolean alive,CallbackInfo ci){((ProgressData)this).ott$data(((ProgressData)old).ott$data().copy());if(!alive){var n=((ProgressData)this).ott$data();n.putLong("pack_respawn_epoch",n.getLong("pack_respawn_epoch")+1);n.putBoolean("pack_respawn_pending",true);}}
}
