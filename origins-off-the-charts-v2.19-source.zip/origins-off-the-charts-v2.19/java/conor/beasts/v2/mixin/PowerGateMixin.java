package conor.beasts.v2.mixin;
import conor.beasts.v2.*;import io.github.apace100.apoli.power.type.PowerType;import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(value=PowerType.class,remap=false) public abstract class PowerGateMixin {
 @Inject(method="isActive",at=@At("HEAD"),cancellable=true)private void gate(CallbackInfoReturnable<Boolean> ci){var p=(PowerType)(Object)this;if(!p.isInitialized())return;String id=p.getPower().getId().toString();if(id.startsWith("beasts_origins:")&&!id.startsWith("beasts_origins:progression/")&&!Progression.allowed(p.getHolder(),id.substring(15)))ci.setReturnValue(false);}
}
