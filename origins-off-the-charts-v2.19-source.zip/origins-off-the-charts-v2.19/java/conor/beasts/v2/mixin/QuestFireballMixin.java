package conor.beasts.v2.mixin;
import conor.beasts.v2.QuestActions;import net.minecraft.entity.projectile.SmallFireballEntity;import net.minecraft.entity.player.PlayerEntity;import net.minecraft.util.hit.BlockHitResult;import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(SmallFireballEntity.class) public abstract class QuestFireballMixin {
 @Inject(method="onBlockHit",at=@At("TAIL"))private void ignite(BlockHitResult hit,CallbackInfo ci){var ball=(SmallFireballEntity)(Object)this;if(ball.getOwner() instanceof PlayerEntity p)QuestActions.ignite(p,hit.getBlockPos().offset(hit.getSide()));}
}
