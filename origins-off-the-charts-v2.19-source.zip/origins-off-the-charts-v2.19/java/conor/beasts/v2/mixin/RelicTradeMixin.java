package conor.beasts.v2.mixin;
import conor.beasts.v2.*;import net.minecraft.entity.passive.VillagerEntity;import net.minecraft.entity.player.PlayerEntity;import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(VillagerEntity.class) public abstract class RelicTradeMixin {
 @Inject(method="prepareOffersFor",at=@At("TAIL"))private void discount(PlayerEntity p,CallbackInfo ci){if(Progression.origin(p).equals("rpi_student")&&Progression.data(p).getInt("tier")>0&&Relics.has(p,"student_id",true)){var card=Relics.find(p,"student_id",true);if(!Relics.spend(card))return;for(var offer:((VillagerEntity)(Object)this).getOffers()){int cost=offer.getDisplayedFirstBuyItem().getCount();int discount=Math.min(cost-1,Math.max(1,(int)Math.ceil(cost*.1)));if(discount>0)offer.increaseSpecialPrice(-discount);}}}
}
