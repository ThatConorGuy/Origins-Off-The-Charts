package conor.beasts.v2.mixin;
import conor.beasts.v2.*;import net.minecraft.entity.*;import net.minecraft.entity.player.PlayerEntity;import net.minecraft.entity.passive.*;import net.minecraft.entity.damage.DamageSource;import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(LivingEntity.class) public abstract class LivingEventsMixin {
 @Inject(method="onDeath",at=@At("HEAD"))private void kill(DamageSource s,CallbackInfo ci){if((Object)this instanceof PlayerEntity p)PlayerTurning.clearPending(p);Progression.kill((LivingEntity)(Object)this,s.getAttacker());}
 @org.spongepowered.asm.mixin.injection.ModifyVariable(method="heal",at=@At("HEAD"),argsOnly=true)private float betaHealing(float amount){return (Object)this instanceof PlayerEntity p&&PlayerTurning.bound(p)?amount*(float)PlayerTurning.POWER:amount;}
 @Inject(method="jump",at=@At("TAIL"))private void jump(CallbackInfo ci){if((Object)this instanceof PlayerEntity p){QuestLog.event(p,"jump",1);if(Progression.origin(p).equals("rubberman"))Progression.event(p,"motion",2,1);}}
 @Inject(method="damage",at=@At("HEAD"),cancellable=true)private void bite(DamageSource s,float amount,CallbackInfoReturnable<Boolean> ci){
  if((Object)this instanceof PlayerEntity victim&&PlayerTurning.loyal(victim,s)){ci.setReturnValue(false);return;}
  if(!(s.getAttacker() instanceof PlayerEntity p)||s.getSource()!=p||!PlayerTurning.canBite(p))return;
  if((Object)this instanceof VillagerEntity v){if(!v.getWorld().isClient){var t=(TurnState)v;if(t.ott$turnTicks()==0){t.ott$start(p.getUuid());PlayerTurning.growl(p);p.sendMessage(net.minecraft.text.Text.literal("[System] The bite takes hold. Fate will decide in one minute."),false);}}ci.setReturnValue(true);}
  else if((Object)this instanceof net.minecraft.server.network.ServerPlayerEntity target&&!target.getWorld().isClient&&(Progression.data(target).getInt("blood_turn_ticks")>0||PlayerTurning.start(target,p)))ci.setReturnValue(true);
 }
}
