package conor.beasts.v2.mixin;
import conor.beasts.v2.BalanceRules;import net.minecraft.entity.LivingEntity;import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(LivingEntity.class)public abstract class DousedHealingMixin {
 @Inject(method="heal",at=@At("HEAD"),cancellable=true)private void extinguished(float amount,CallbackInfo ci){if(BalanceRules.doused((LivingEntity)(Object)this))ci.cancel();}
}
