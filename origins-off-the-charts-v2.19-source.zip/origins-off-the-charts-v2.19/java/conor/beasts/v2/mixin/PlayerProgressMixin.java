package conor.beasts.v2.mixin;
import conor.beasts.v2.*;import net.minecraft.entity.player.PlayerEntity;import net.minecraft.server.network.ServerPlayerEntity;import net.minecraft.nbt.NbtCompound;import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(PlayerEntity.class) public abstract class PlayerProgressMixin implements ProgressData {
 @Unique private NbtCompound ott$state=new NbtCompound();public NbtCompound ott$data(){return ott$state;}public void ott$data(NbtCompound n){ott$state=n;}
 @Inject(method="writeCustomDataToNbt",at=@At("TAIL"))private void save(NbtCompound n,CallbackInfo ci){n.put("OffTheChartsV2",ott$state);}
 @Inject(method="readCustomDataFromNbt",at=@At("TAIL"))private void load(NbtCompound n,CallbackInfo ci){ott$state=n.getCompound("OffTheChartsV2");}
 @Inject(method="tick",at=@At("TAIL"))private void tick(CallbackInfo ci){if((Object)this instanceof ServerPlayerEntity p)Progression.tick(p);}
 @Inject(method="addExperience",at=@At("HEAD"))private void xp(int amount,CallbackInfo ci){Progression.xp((PlayerEntity)(Object)this,amount);}
}
