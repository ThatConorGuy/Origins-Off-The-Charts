package conor.beasts.v2.mixin;
import conor.beasts.v2.*;import net.minecraft.entity.AreaEffectCloudEntity;import net.minecraft.nbt.NbtCompound;import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(AreaEffectCloudEntity.class)public abstract class TrapCloudMixin implements TrapState {
 @Unique private String ott$trap="";
 public String ott$trap(){return ott$trap;}public void ott$trap(String id){ott$trap=id;}
 @Inject(method="tick",at=@At("TAIL"))private void trap(CallbackInfo ci){SurvivalItems.tick((AreaEffectCloudEntity)(Object)this,ott$trap);}
 @Inject(method="writeCustomDataToNbt",at=@At("TAIL"))private void save(NbtCompound n,CallbackInfo ci){if(!ott$trap.isEmpty())n.putString("OTT_Trap",ott$trap);}
 @Inject(method="readCustomDataFromNbt",at=@At("TAIL"))private void load(NbtCompound n,CallbackInfo ci){ott$trap=n.getString("OTT_Trap");}
}
