package conor.beasts.v2.mixin;
import conor.beasts.v2.*;import net.minecraft.entity.LivingEntity;import net.minecraft.entity.player.PlayerEntity;import net.minecraft.entity.damage.DamageSource;import net.minecraft.registry.tag.DamageTypeTags;import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;
@Mixin(LivingEntity.class)public abstract class SkillDamageMixin {
 @ModifyVariable(method="damage",at=@At("HEAD"),argsOnly=true,ordinal=0)private float fire(float amount,DamageSource source,float original){amount=Wolfsbane.damage((LivingEntity)(Object)this,source,amount);return source.isIn(DamageTypeTags.IS_FIRE)&&source.getAttacker() instanceof PlayerEntity p?amount+SkillSystem.fireBonus(p):amount;}
}
