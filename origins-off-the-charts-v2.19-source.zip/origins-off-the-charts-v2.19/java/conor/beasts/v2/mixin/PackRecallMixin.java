package conor.beasts.v2.mixin;
import conor.beasts.v2.*;import net.minecraft.entity.passive.WolfEntity;import net.minecraft.nbt.NbtCompound;import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(WolfEntity.class) public abstract class PackRecallMixin implements RecallState {
 @Unique private long ott$recallEpoch;public void ott$rememberRecall(long epoch){ott$recallEpoch=epoch;}
 @Inject(method="tick",at=@At("TAIL"))private void recall(CallbackInfo ci){var wolf=(WolfEntity)(Object)this;if(wolf.getWorld().isClient||!wolf.isTamed()||wolf.getOwnerUuid()==null)return;var owner=wolf.getServer().getPlayerManager().getPlayer(wolf.getOwnerUuid());if(owner==null||!owner.isAlive())return;long epoch=Progression.data(owner).getLong("pack_respawn_epoch");if(epoch>ott$recallEpoch){ott$recallEpoch=epoch;PackRecall.recall(wolf,owner);}}
 @Inject(method="writeCustomDataToNbt",at=@At("TAIL"))private void save(NbtCompound n,CallbackInfo ci){n.putLong("OTT_RecallEpoch",ott$recallEpoch);}
 @Inject(method="readCustomDataFromNbt",at=@At("TAIL"))private void load(NbtCompound n,CallbackInfo ci){ott$recallEpoch=n.getLong("OTT_RecallEpoch");}
}
