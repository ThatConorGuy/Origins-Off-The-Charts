package conor.beasts.v2.mixin;
import conor.beasts.v2.*;import net.minecraft.item.*;import net.minecraft.util.ActionResult;import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(BlockItem.class) public abstract class QuestPlaceMixin {
 @Inject(method="place(Lnet/minecraft/item/ItemPlacementContext;)Lnet/minecraft/util/ActionResult;",at=@At("RETURN"))private void place(ItemPlacementContext c,CallbackInfoReturnable<ActionResult> ci){if(ci.getReturnValue().isAccepted())QuestActions.place(c.getPlayer(),c.getBlockPos());}
}
