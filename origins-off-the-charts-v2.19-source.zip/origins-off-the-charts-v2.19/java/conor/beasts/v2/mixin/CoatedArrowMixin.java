package conor.beasts.v2.mixin;
import conor.beasts.v2.*;import net.minecraft.entity.projectile.ArrowEntity;import net.minecraft.entity.data.*;import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ArrowEntity.class)public abstract class CoatedArrowMixin implements CoatedArrow {
 @Unique private static final TrackedData<Boolean> OTT_COATED=DataTracker.registerData(ArrowEntity.class,TrackedDataHandlerRegistry.BOOLEAN);
 @Inject(method="initDataTracker",at=@At("TAIL"))private void init(DataTracker.Builder builder,CallbackInfo ci){builder.add(OTT_COATED,false);}
 @Inject(method="tick",at=@At("HEAD"))private void sync(CallbackInfo ci){var a=(ArrowEntity)(Object)this;if(!a.getWorld().isClient)a.getDataTracker().set(OTT_COATED,Wolfsbane.coated(a.getItemStack()));}
 public boolean ott$coated(){return ((ArrowEntity)(Object)this).getDataTracker().get(OTT_COATED);}
}
