package conor.beasts.v2.mixin;
import conor.beasts.v2.*;import net.minecraft.item.*;import net.minecraft.util.ActionResult;import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(FlintAndSteelItem.class) public abstract class QuestUseMixin {
 @Inject(method="useOnBlock",at=@At("RETURN"))private void fire(ItemUsageContext c,CallbackInfoReturnable<ActionResult> ci){if(ci.getReturnValue().isAccepted())QuestActions.ignite(c.getPlayer(),c.getBlockPos().offset(c.getSide()));}
}
