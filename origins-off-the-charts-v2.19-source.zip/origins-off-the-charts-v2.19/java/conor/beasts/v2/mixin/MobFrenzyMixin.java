package conor.beasts.v2.mixin;
import conor.beasts.v2.*;import net.minecraft.entity.passive.TameableEntity;import net.minecraft.entity.LivingEntity;import net.minecraft.entity.passive.WolfEntity;import net.minecraft.entity.player.PlayerEntity;import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(TameableEntity.class)public abstract class MobFrenzyMixin {
 @Inject(method="canTarget(Lnet/minecraft/entity/LivingEntity;)Z",at=@At("HEAD"),cancellable=true)private void target(LivingEntity e,CallbackInfoReturnable<Boolean> ci){if((Object)this instanceof WolfEntity w&&((WolfState)w).ott$turned()){if(e.getUuid().equals(w.getOwnerUuid()))ci.setReturnValue(false);else if(((WolfState)w).ott$frenzy())ci.setReturnValue(e!=w&&e.isAlive()&&!(e instanceof PlayerEntity p&&(p.isCreative()||p.isSpectator())));}}
}
