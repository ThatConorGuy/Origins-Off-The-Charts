package conor.beasts.ui;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
public final class ProgressKeys implements ClientModInitializer {
 private boolean held;
 public void onInitializeClient(){var key=KeyBindingHelper.registerKeyBinding(new KeyBinding("key.beasts_origins.progression",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_P,"category.beasts_origins"));ClientTickEvents.START_CLIENT_TICK.register(client->{var bound=KeyBindingHelper.getBoundKeyOf(key);int code=bound.getCode();boolean down=code>=0&&(bound.getCategory()==InputUtil.Type.MOUSE?GLFW.glfwGetMouseButton(client.getWindow().getHandle(),code)==GLFW.GLFW_PRESS:InputUtil.isKeyPressed(client.getWindow().getHandle(),code));if(down&&!held&&client.player!=null&&client.currentScreen==null){if(bound.equals(KeyBindingHelper.getBoundKeyOf(client.options.socialInteractionsKey)))while(client.options.socialInteractionsKey.wasPressed()){}client.player.networkHandler.sendChatCommand("ott menu");}held=down;while(key.wasPressed()){};});}
}
