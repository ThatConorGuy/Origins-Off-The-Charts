execute store result score @s bw_target run resource get @s beasts_origins:werewolf/transition_target
execute store result score @s bw_energy run resource get @s beasts_origins:werewolf/resource
execute store result score @s bw_dark run resource get @s beasts_origins:werewolf/night
execute if score @s bw_dark matches 0 if score @s bw_energy matches 0 run scoreboard players set @s bw_target 0
resource operation @s beasts_origins:werewolf/form_state = @s bw_target
resource set @s beasts_origins:werewolf/transition_ticks 0
resource set @s beasts_origins:werewolf/transition_target 0
