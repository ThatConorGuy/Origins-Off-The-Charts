execute if score @s bw_met matches 0 if score @s bw_overdue matches 0 run scoreboard players operation @s bw_last = @s bw_due
execute if score @s bw_met matches 0 if score @s bw_overdue matches 0 run scoreboard players remove @s bw_last 1
execute if score @s bw_met matches 0 run scoreboard players set @s bw_overdue 1
execute if score @s bw_met matches 0 run tellraw @s {"text":"The full moon rises. Your hunt is overdue: kill 1 player or 30 hostile mobs to restore your maximum health.","color":"red"}
execute if score @s bw_met matches 1 run scoreboard players set @s bw_mobs 0
execute if score @s bw_met matches 1 run scoreboard players set @s bw_pvp 0
scoreboard players set @s bw_met 0
scoreboard players operation @s bw_due = @s bw_day
scoreboard players operation @s bw_due /= #eight bw_math
scoreboard players add @s bw_due 1
scoreboard players operation @s bw_due *= #eight bw_math
execute if score @s bw_phase matches 0 if score @s bw_time matches ..12999 run scoreboard players remove @s bw_due 8
