execute store result score @s bw_transition run resource get @s beasts_origins:werewolf/transition_ticks
execute if score @s bw_transition matches 1.. run particle minecraft:dust{color:[0.0f,0.0f,0.0f],scale:1.6f} ~ ~1 ~ 0.7 0.9 0.7 0.02 35 force
execute if score @s bw_transition matches 1.. run particle minecraft:large_smoke ~ ~1 ~ 0.6 0.8 0.6 0.03 10 force
execute if score @s bw_transition matches 1.. run scoreboard players remove @s bw_transition 1
resource operation @s beasts_origins:werewolf/transition_ticks = @s bw_transition
execute if score @s bw_transition matches 0 run function beasts_origins:werewolf/finish_transition
