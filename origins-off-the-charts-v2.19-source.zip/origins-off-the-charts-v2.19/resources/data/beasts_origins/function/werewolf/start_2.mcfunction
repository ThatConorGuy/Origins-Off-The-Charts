resource set @s beasts_origins:werewolf/transition_target 2
resource set @s beasts_origins:werewolf/transition_ticks 60
