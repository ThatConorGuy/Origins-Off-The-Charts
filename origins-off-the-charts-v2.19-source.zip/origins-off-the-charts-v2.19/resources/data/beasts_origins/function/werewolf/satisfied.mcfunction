execute if score @s bw_met matches 0 if score @s bw_loss matches 1.. run tellraw @s {"text":"Killer Instinct satisfied. Your lost heart capacity returns.","color":"green"}
execute if score @s bw_met matches 0 if score @s bw_loss matches 0 run tellraw @s {"text":"Killer Instinct satisfied.","color":"green"}
execute if score @s bw_met matches 0 run title @s actionbar {"text":""}
scoreboard players set @s bw_met 1
scoreboard players set @s bw_overdue 0
scoreboard players set @s bw_loss 0
resource set @s beasts_origins:werewolf/hunt_loss 0
