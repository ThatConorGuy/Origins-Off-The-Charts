scoreboard objectives add bw_init dummy
scoreboard objectives add bw_day dummy
scoreboard objectives add bw_time dummy
scoreboard objectives add bw_due dummy
scoreboard objectives add bw_phase dummy
scoreboard objectives add bw_night dummy
scoreboard objectives add bw_last dummy
scoreboard objectives add bw_overdue dummy
scoreboard objectives add bw_transition dummy
scoreboard objectives add bw_target dummy
scoreboard objectives add bw_form dummy
scoreboard objectives add bw_energy dummy
scoreboard objectives add bw_dark dummy
scoreboard objectives add bw_forced dummy
scoreboard objectives add bw_loss dummy
scoreboard objectives add bw_mobs dummy
scoreboard objectives add bw_pvp dummy
scoreboard objectives add bw_met dummy
scoreboard objectives add bw_delta dummy
scoreboard objectives add bw_left dummy
scoreboard objectives add bw_math dummy
scoreboard players set #eight bw_math 8
scoreboard players set #day bw_math 24000
scoreboard players set #ready bw_math 1
