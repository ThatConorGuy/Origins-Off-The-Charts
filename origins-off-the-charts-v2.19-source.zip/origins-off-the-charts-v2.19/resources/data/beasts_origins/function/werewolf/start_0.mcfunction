resource set @s beasts_origins:werewolf/transition_target 0
resource set @s beasts_origins:werewolf/transition_ticks 60
