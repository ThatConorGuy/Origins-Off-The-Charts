scoreboard players set @s bw_init 1
scoreboard players operation @s bw_due = @s bw_day
scoreboard players operation @s bw_due /= #eight bw_math
scoreboard players add @s bw_due 1
scoreboard players operation @s bw_due *= #eight bw_math
scoreboard players set @s bw_mobs 0
scoreboard players set @s bw_pvp 0
scoreboard players set @s bw_met 0
scoreboard players set @s bw_overdue 0
scoreboard players set @s bw_loss 0
scoreboard players operation @s bw_last = @s bw_day
