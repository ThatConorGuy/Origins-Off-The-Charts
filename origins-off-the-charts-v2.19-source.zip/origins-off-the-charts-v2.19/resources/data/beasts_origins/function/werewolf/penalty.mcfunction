scoreboard players set @s bw_loss 1
