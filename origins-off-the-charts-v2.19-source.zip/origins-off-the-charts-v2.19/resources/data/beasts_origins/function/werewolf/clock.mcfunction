execute in minecraft:overworld store result score @s bw_day run time query day
execute in minecraft:overworld store result score @s bw_time run time query daytime
scoreboard players add @s bw_init 0
execute if score @s bw_init matches 0 run function beasts_origins:werewolf/init
scoreboard players operation @s bw_phase = @s bw_day
scoreboard players operation @s bw_phase %= #eight bw_math
scoreboard players operation @s bw_night = @s bw_day
execute if score @s bw_time matches ..12999 run scoreboard players remove @s bw_night 1
resource set @s beasts_origins:werewolf/night 0
execute if score @s bw_time matches 13000..22999 run resource set @s beasts_origins:werewolf/night 1
execute if score @s bw_time matches 13000..22999 run resource set @s beasts_origins:werewolf/resource 100
execute store result score @s bw_forced run resource get @s beasts_origins:werewolf/blood_moon
resource set @s beasts_origins:werewolf/blood_moon 0
execute unless entity @s[nbt={OffTheChartsV2:{moon_control:1b}}] if score @s bw_phase matches 0 if score @s bw_time matches 13000..22999 run resource set @s beasts_origins:werewolf/blood_moon 1
execute unless entity @s[nbt={OffTheChartsV2:{moon_control:1b}}] if score @s bw_phase matches 0 if score @s bw_time matches 13000..22999 run function beasts_origins:werewolf/request_2
execute unless score @s bw_phase matches 0 if score @s bw_forced matches 1 run function beasts_origins:werewolf/request_0
execute if score @s bw_time matches ..12999 if score @s bw_forced matches 1 run function beasts_origins:werewolf/request_0
execute if score @s bw_time matches 23000.. if score @s bw_forced matches 1 run function beasts_origins:werewolf/request_0
execute if score @s bw_day > @s bw_due run function beasts_origins:werewolf/deadline
execute if score @s bw_day = @s bw_due if score @s bw_time matches 13000.. run function beasts_origins:werewolf/deadline
execute if score @s bw_overdue matches 1 run function beasts_origins:werewolf/penalty
resource operation @s beasts_origins:werewolf/hunt_loss = @s bw_loss
scoreboard players operation @s bw_left = @s bw_due
scoreboard players operation @s bw_left -= @s bw_day
scoreboard players operation @s bw_left *= #day bw_math
scoreboard players add @s bw_left 13000
scoreboard players operation @s bw_left -= @s bw_time
resource operation @s beasts_origins:werewolf/full_moon_timer = @s bw_left
execute if score @s bw_met matches 0 if score @s bw_left matches 0..72000 run title @s actionbar [{"text":"Hunt: ","color":"red"},{"score":{"name":"@s","objective":"bw_mobs"}},{"text":"/30 hostile mobs or "},{"score":{"name":"@s","objective":"bw_pvp"}},{"text":"/1 player"}]
