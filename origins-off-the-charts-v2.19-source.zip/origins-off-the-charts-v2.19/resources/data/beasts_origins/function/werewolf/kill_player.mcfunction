execute unless score @s bw_init matches 1 run function beasts_origins:werewolf/clock
execute if score @s bw_met matches 0 run scoreboard players add @s bw_pvp 1
execute if score @s bw_met matches 0 run function beasts_origins:werewolf/satisfied
