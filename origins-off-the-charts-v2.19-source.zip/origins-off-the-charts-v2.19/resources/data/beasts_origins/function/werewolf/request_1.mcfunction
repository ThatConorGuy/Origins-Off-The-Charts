execute store result score @s bw_form run resource get @s beasts_origins:werewolf/form_state
execute store result score @s bw_transition run resource get @s beasts_origins:werewolf/transition_ticks
execute store result score @s bw_target run resource get @s beasts_origins:werewolf/transition_target
execute if score @s bw_transition matches 0 unless score @s bw_form matches 1 run function beasts_origins:werewolf/start_1
execute if score @s bw_transition matches 1.. unless score @s bw_target matches 1 run function beasts_origins:werewolf/start_1
