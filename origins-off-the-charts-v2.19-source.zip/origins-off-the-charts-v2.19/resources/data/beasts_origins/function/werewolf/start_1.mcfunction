resource set @s beasts_origins:werewolf/transition_target 1
resource set @s beasts_origins:werewolf/transition_ticks 60
