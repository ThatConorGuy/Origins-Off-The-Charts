# Version history

- Edition 1: **v1.1**
- Edition 2: **v1.2**
- Edition 3: **v1.3**
- Edition 4: **v1.4**
- Edition 5: **v1.5**
- Edition 6: **v1.6**
- Edition 7: **v1.7**
- Edition 8: **v1.8**
- Edition 9: **v1.9**
- Edition 10: **v1.10**
- Edition 11: **v1.11**
- Edition 12: **v1.12**
- Edition 13: **v1.13**
- Edition 14: **v1.14**
- Edition 15: **v1.15**
- Edition 16: **v1.16**
- Edition 17: **v1.17**
- Edition 18: **v1.18**
- Edition 19: **v1.19**
- Edition 20: **v1.20**
- Edition 21: **v1.21**

- **v2** (internal SemVer 2.0.0): awakening, evolution, quests and werewolf packs.
- **v2.1** (internal SemVer 2.1.0): operator pause/unpause commands for a shared start.
- Future feature/fix releases: **v2.1**, **v2.2**, and so on.

Legacy JAR and source archive filenames now use the corresponding v1.N labels. Their original binary contents and timestamps remain intact. Early port builds are labeled v1.0-port.1 and v1.0-port.2.

- **v2.2** (internal SemVer 2.2.0): P-key journal, hidden locked descriptions, 42 upgrade paths, automatic progress migration and longer announcements.

- **v2.3** (internal SemVer 2.3.0): Hell Hound wetness curse, Berserker armor/attack/recovery costs, lighter Yeti mobility and attack costs.

- **v2.4** (internal SemVer 2.4.0): Origins-style compact upgrade selector, separate skill details, and ongoing quests with recent-combination avoidance and free basic-objective swaps.

## v2.5
- Fixed evolution panel blur caused by the vanilla screen applying background blur again after the panel was drawn.

## v2.6
- Ten persistent origin-themed evolution stages with increasing EXP thresholds and fresh activity trials.
- Themed difficulty-scaled quests, completion/availability notifications, 30-150 second intervals, and specific nearby threats.
- Evolution tab and EXP terminology; two modest extra upgrade ranks gated by levels 7 and 10.
- Existing player records and unlocked levels preserved.

## v2.7
- Centered header title and Nether Star in the Origins frame.
- Raised upgrade rows and footer into the panel, keeping scrolled skill text clear of the footer.

## v2.8
- 224 origin-specific quest templates with longer goals and difficulty-scaled EXP rewards.
- Twenty limited-use relics in dangerous chests.
- Werewolf pack scans bounded to 80 blocks, respawn regrouping, one-block stepping and 2.45-block full transformation.
- Wolfsbane nausea ends with poison; existing saved progress preserved.

## v2.9
- Both transformed werewolf states pass through leaves, including downward, while human form retains normal collisions.
- One-block stepping remains enabled in both transformed states without a manual jump or sprint interruption.

## v2.10
- Reduced all evolution EXP thresholds by 30 percent, preserving quest payouts and existing progress.

## v2.11
- Lowered purchased skill levels 2-5 evolution locks to 1/2/3/4, respecting the skill unlock. Prices and saved ranks retained.

## v2.12
- Added operator-only `/ott awaken [players]`, bypassing grace/time/pause while preserving the awakening ritual and existing progress.
- Added `/ott evolve [players]` and `/ott unlockshop [players]` for operator debugging.

## v2.13
- Added `/ott maxupgrades <players>` for maximum evolution and all current-origin upgrade ranks.

## v2.14
- Rubberman gains 12 extra blocks of safe fall distance after awakening (15 total), retaining half fall damage beyond that. Saved progress is unchanged.

## v2.15
- Pink tulips become black-petaled, green-stemmed Wolfsbane, including existing plants. Only Wolfsbane triggers the werewolf flower curse, after five continuous seconds carrying it or touching its planted/potted block. Leaving resets exposure; antidote blocks exposure effects.
- Shapeless coating: one Wolfsbane plus one sword or axe. Preserves wear, enchantments and custom name; black blades for all twelve vanilla swords/axes. Adds six melee damage before other modifiers/defenses against awakened Werewolf players or blood-bound turned wolves. Coatings are permanent and cannot stack.
- Rodent Repellent: three uses; twenty-second cloud of radius six, slowing and weakening squirrels and preventing concealment/gliding. Bug Trap: three uses; one-minute radius-two area slowing and weakening grasshoppers and blocking spring legs/gliding. Penalties linger five seconds after leaving. Natural unopened chest loot has a 12 percent roll for one of these; dangerous relic rolls also include them. Other origins are unaffected. Clouds and remaining duration persist in world saves.
- Grasshopper, Sneaky Squirrel, Rubberman and RPI Student need half the hunter EXP thresholds and half their previous trial targets. Quest payouts, saved EXP, ranks and previous evolutions stay intact; the P menu uses the new origin-specific thresholds.

## v2.16
- Awakened werewolves can eat bones for eight hunger points (four bars) and bone blocks for twenty points (the full row), in any form. Uses normal eating, consumes one item and caps at twenty hunger. No bonus saturation. Other origins and dormant players keep normal item behavior.

## v2.17
- WolfsBane Flower (formerly pink tulip) causes exposure within a spherical three-block radius of planted/potted flowers, retaining five-second grace and inventory exposure.
- Flower crafting yields one tagged WolfsBane Extract instead of pink dye. Combine one extract with one arrow, sword or axe. One arrow per craft, with the existing six-damage bonus on arrow hits against werewolves or turned wolves. Other pink dye recipes remain ordinary dye. Existing coated weapons retain their coating.

## v2.18
Black redstone-style WolfsBane Extract; black arrow tips and synchronized smoke trails; werewolf-only dark item and flower outlines. Existing extract stacks migrate their appearance without changing progress.

## v2.19
Villager-converted wolves now have 60 health. Player bites can create conversion-only Beta Werewolves (40% success after one minute); failed hosts die retaining their previous origin and progress. Betas inherit two-thirds of werewolf stat bonuses and healing, follow their turner's unlocks/upgrades, cannot use Alpha abilities or grow independently, and cannot inflict attributed combat damage on their turner. Bites growl; successful turns show a Beta Werewolf title. Conversion/bond saves survive death, logout and JAR replacement. Awakening subtitle shortened to prevent overflow.
