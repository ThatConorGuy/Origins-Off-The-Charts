"""Build the v2 additions against a provided Minecraft/Fabric toolchain."""
from pathlib import Path
import argparse,subprocess,zipfile,shutil
root=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
for name in ['java','compiler','remapper','minecraft_named','minecraft_intermediary','apoli_named','yarn_tiny','classpath']:p.add_argument('--'+name.replace('_','-'),required=True)
p.add_argument('--origins',required=True,help='Origins jar for Minecraft 1.21.1')
p.add_argument('--fabric-api',required=True,help='Fabric API jar for Minecraft 1.21.1')
p.add_argument('--output',default='origins-off-the-charts-1.21.1-v2.19.jar');a=p.parse_args();tmp=root/'build';tmp.mkdir(exist_ok=True)
api_cp=[]
with zipfile.ZipFile(a.fabric_api) as api:
 for part in ['fabric-key-binding-api','fabric-lifecycle-events']:
  member=next(n for n in api.namelist() if part in n and n.endswith('.jar'));src=tmp/(part+'.jar');src.write_bytes(api.read(member));dst=tmp/(part+'-named.jar')
  subprocess.run([a.java,'-jar',a.remapper,str(src),str(dst),a.yarn_tiny,'intermediary','named',a.minecraft_intermediary],check=True);api_cp.append(str(dst))
origins_named=tmp/'origins-named.jar'
subprocess.run([a.java,'-jar',a.remapper,a.origins,str(origins_named),a.yarn_tiny,'intermediary','named',a.minecraft_intermediary],check=True)
api_cp.append(str(origins_named))
cp=':'.join(api_cp)+':'+a.minecraft_named+':'+a.apoli_named+':'+a.classpath
subprocess.run([a.java,'-jar',a.compiler,'-21','-proc:none','-cp',cp,'-d',str(tmp/'classes'),*[str(f) for f in (root/'java').rglob('*.java')]],check=True)
with zipfile.ZipFile(tmp/'named.jar','w') as z:
 for f in (tmp/'classes').rglob('*.class'):z.write(f,f.relative_to(tmp/'classes'))
subprocess.run([a.java,'-jar',a.remapper,str(tmp/'named.jar'),str(tmp/'inter.jar'),a.yarn_tiny,'named','intermediary',a.minecraft_named,a.apoli_named],check=True)
subprocess.run([a.java,'-jar',a.compiler,'-21','-proc:none','-cp',cp,'-d',str(tmp/'tools'),str(root/'PatchAnnotations.java')],check=True)
with zipfile.ZipFile(tmp/'inter.jar') as z:z.extractall(tmp/'inter')
subprocess.run([a.java,'-cp',str(tmp/'tools')+':'+cp,'PatchAnnotations',a.yarn_tiny,a.minecraft_intermediary,str(tmp/'inter')],check=True)
with zipfile.ZipFile(a.output,'w',zipfile.ZIP_DEFLATED) as z:
 for f in (root/'resources').rglob('*'):
  if f.is_file() and not str(f.relative_to(root/'resources')).startswith(('conor/beasts/v2/','conor/beasts/ui/')):z.write(f,f.relative_to(root/'resources'))
 for f in (tmp/'inter').rglob('*.class'):z.write(f,f.relative_to(tmp/'inter'))
print(a.output)
